"""Sales by DELIVERY day, plus a local order cache for looking back at older days.

User rule (2026-11-11): a day's sales = orders that were DELIVERED that day (the "Delivered"
entry in stateLogs), not orders received/completed that day. Orders that were later canceled
(refunded) are not counted as sales.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

from .util import JsonStore, log, parse_dt

NOT_SALES = {"Canceled"}
DISPUTE_STATES = {"Disputed", "DeliveredDisputed"}
REFRESH_DAYS = 3      # re-read the newest days on every sync: states (dispute/cancel) still change
KEEP_DAYS = 730       # keep two years: buyer history looks far back
SLIM_VERSION = 2      # bump when slim() gains fields -> one full re-read
MAX_PAGES = 400


def delivered_at(o: dict) -> datetime | None:
    for s in o.get("stateLogs") or []:
        if s.get("state") == "Delivered" and s.get("createdDate"):
            return parse_dt(s["createdDate"])
    return None


def slim(o: dict) -> dict:
    """The few fields we need from a seller order (keeps the cache small)."""
    det = o.get("orderOfferDetails") or {}
    d = delivered_at(o)
    return {
        "id": o["id"],
        "created": o["createdDate"],
        "delivered": d.isoformat() if d else None,
        "state": (o.get("state") or {}).get("state"),
        "total": float((o.get("totalPrice") or {}).get("amount") or 0),
        "qty": int(o.get("purchaseQuantity") or 1),
        "title": (det.get("offerTitle") or "?").strip(),
        "offer": o.get("offerId"),
        "buyer": o.get("buyerUsername") or "",
        "dispute": ((o.get("latestDispute") or {}).get("reason") or "").replace("_", " "),
        "review": (o.get("review") or {}).get("reviewRating"),
    }


@dataclass
class DayStat:
    day: date
    orders: int = 0
    gross: float = 0.0
    disputed: int = 0
    canceled: int = 0
    per_offer: dict = field(default_factory=dict)  # title -> [orders, gross]


def day_stats(orders, first: date, last: date, tz) -> dict[date, DayStat]:
    """Group slim orders by the local day they were delivered (first..last inclusive)."""
    stats: dict[date, DayStat] = {}
    d = first
    while d <= last:
        stats[d] = DayStat(d)
        d += timedelta(days=1)
    for o in orders:
        if not o.get("delivered"):
            continue  # still Paid (not delivered yet) or canceled before delivery
        st = stats.get(parse_dt(o["delivered"]).astimezone(tz).date())
        if st is None:
            continue
        if o.get("state") in NOT_SALES:
            st.canceled += 1
            continue
        st.orders += 1
        st.gross += o["total"]
        if o.get("state") in DISPUTE_STATES:
            st.disputed += 1
        row = st.per_offer.setdefault(o["title"], [0, 0.0])
        row[0] += 1
        row[1] += o["total"]
    return stats


class OrderHistory:
    """Local cache of seller orders (data/orders_cache.json) so older days load instantly."""

    def __init__(self, api, path: Path):
        self.api = api
        self.store = JsonStore(path)
        self.store.data.setdefault("orders", {})
        if not self.store.data["orders"]:
            self.store.data["slim_version"] = SLIM_VERSION  # a new cache is already current
        for oid, o in self.store.data["orders"].items():
            o.setdefault("id", oid)  # older caches only had the id as the key

    @property
    def orders(self) -> dict:
        return self.store.data["orders"]

    def covered_from(self) -> datetime | None:
        """Oldest moment the cache is complete from (None = everything ever)."""
        c = self.store.data.get("covered_since")
        if c:
            dt = parse_dt(c)
            return None if dt.year < 2000 else dt
        oldest = min((parse_dt(o["created"]) for o in self.orders.values()), default=None)
        return oldest

    def sync(self, days: int, progress=None, now: datetime | None = None, refresh_days: int = REFRESH_DAYS) -> int:
        """Make sure the cache holds every order of the last `days` days. Returns orders read.
        Once covered, only the newest `refresh_days` are re-read (states like disputes still change)."""
        now = now or datetime.now(timezone.utc)
        upgrade = self.store.data.get("slim_version", 1) < SLIM_VERSION
        if upgrade:  # cache written by an older version lacks fields (e.g. buyer): re-read everything once
            refresh_days = KEEP_DAYS
            log("history", "cache format upgrade: re-reading all orders once")
        target = now - timedelta(days=days)
        covered = self.store.data.get("covered_since")
        covered = parse_dt(covered) if covered else None
        newest = max((parse_dt(o["created"]) for o in self.orders.values()), default=None)
        stop_at = target
        if covered and covered <= target and newest:
            stop_at = max(target, newest - timedelta(days=refresh_days))  # only refresh the top
        if upgrade:
            stop_at = now - timedelta(days=KEEP_DAYS)

        cursor, read, pages, oldest, exhausted = None, 0, 0, None, False
        while pages < MAX_PAGES:
            data = self.api.seller_orders(page_size=50, cursor=cursor) or {}
            results = data.get("results") or []
            pages += 1
            for o in results:
                self.orders[o["id"]] = slim(o)
                if o.get("sellerUsername"):
                    self.store.data["seller"] = o["sellerUsername"]
                read += 1
                c = parse_dt(o["createdDate"])
                oldest = c if oldest is None or c < oldest else oldest
            if progress:
                progress(pages, oldest)
            cursor = data.get("nextPageCursor")
            if not results or not cursor:
                exhausted = True
                break
            if parse_dt(results[-1]["createdDate"]) < stop_at:
                break

        if exhausted:
            self.store.data["covered_since"] = "1970-01-01T00:00:00+00:00"
        elif stop_at == target and oldest is not None:
            self.store.data["covered_since"] = oldest.isoformat()
        if upgrade and exhausted:
            self.store.data["slim_version"] = SLIM_VERSION
        self._prune(now)
        self.store.data["synced_at"] = now.isoformat()
        self.store.save()
        log("history", f"synced {read} orders ({pages} pages), cache holds {len(self.orders)}")
        return read

    def backfill_historical(self) -> int:
        """Orders older than ~3 months sit in a separate 'Historical' list. They are final
        (completed/canceled), so reading them once is enough - used for buyer history."""
        if self.store.data.get("historical_done"):
            return 0
        cursor, read = None, 0
        for _ in range(MAX_PAGES):
            data = self.api.seller_orders(page_size=50, cursor=cursor, group="Historical") or {}
            results = data.get("results") or []
            for o in results:
                self.orders.setdefault(o["id"], slim(o))
                read += 1
            cursor = data.get("nextPageCursor")
            if not results or not cursor:
                break
        self.store.data["historical_done"] = True
        self._prune(datetime.now(timezone.utc))
        self.store.save()
        log("history", f"historical orders read: {read}, cache holds {len(self.orders)}")
        return read

    def stats(self, first: date, last: date, tz) -> dict[date, DayStat]:
        return day_stats(self.orders.values(), first, last, tz)

    def _prune(self, now: datetime) -> None:
        cutoff = now - timedelta(days=KEEP_DAYS)
        for oid in [k for k, o in self.orders.items() if parse_dt(o["created"]) < cutoff]:
            del self.orders[oid]
