"""App version + where updates come from.

To ship an update: bump APP_VERSION, then run publish_update.cmd (see tools/publish_update.py).
"""
import os

APP_VERSION = "2.4.0"

# latest.json of the public release repo (raw GitHub). Override with ELDORADO_UPDATE_MANIFEST for testing.
UPDATE_MANIFEST = os.environ.get(
    "ELDORADO_UPDATE_MANIFEST",
    "https://raw.githubusercontent.com/Scripterkaa/eldorado-sales/main/latest.json",
)
