"""Load config.json (+ .env for credentials)."""
from __future__ import annotations

import json
import os
from pathlib import Path
from zoneinfo import ZoneInfo

from .util import load_env

ROOT = Path(__file__).resolve().parent.parent

DEFAULTS = {
    "timezone": "Asia/Bangkok",
    "discord_webhook": "",
    "discord_mention": "",
    "orders": {"enabled": True, "interval_seconds": 60, "page_size": 50,
               "notify_new": True, "notify_completed": False, "auto_deliver_offer_ids": []},
    "schedule": {"enabled": False, "online": [["09:00", "02:00"]]},
    "report": {"enabled": True, "time": "00:05", "top_offers": 8},
}


def _merge(base: dict, override: dict) -> dict:
    out = dict(base)
    for k, v in (override or {}).items():
        if k.startswith("_"):
            continue  # "_comment" keys
        out[k] = _merge(base[k], v) if isinstance(v, dict) and isinstance(base.get(k), dict) else v
    return out


def load_config(path: Path | None = None) -> dict:
    load_env(ROOT / ".env")
    path = path or ROOT / "config.json"
    user = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
    user.pop("pricer", None)  # price features were removed (2026-11-12); ignore old config
    cfg = _merge(DEFAULTS, user)
    cfg["_tz"] = ZoneInfo(cfg["timezone"])
    cfg["_client_id"] = os.environ.get("ELDORADO_CLIENT_ID", "")
    cfg["_client_secret"] = os.environ.get("ELDORADO_CLIENT_SECRET", "")
    cfg["discord_webhook"] = os.environ.get("DISCORD_WEBHOOK") or cfg["discord_webhook"]
    return cfg


def save_config(cfg: dict, path: Path | None = None) -> None:
    """Write config.json (internal "_" keys and secrets stay out of it)."""
    path = path or ROOT / "config.json"
    clean = {k: v for k, v in cfg.items() if not k.startswith("_")}
    if os.environ.get("DISCORD_WEBHOOK") == clean.get("discord_webhook"):
        clean["discord_webhook"] = ""  # lives in .env
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(clean, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def save_env(values: dict[str, str], path: Path | None = None) -> None:
    """Update KEY=VALUE lines in .env, keeping any other lines."""
    path = path or ROOT / ".env"
    lines = path.read_text(encoding="utf-8").splitlines() if path.exists() else []
    done = set()
    for i, line in enumerate(lines):
        key = line.split("=", 1)[0].strip()
        if key in values and not line.lstrip().startswith("#"):
            lines[i] = f"{key}={values[key]}"
            done.add(key)
    lines += [f"{k}={v}" for k, v in values.items() if k not in done]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    for k, v in values.items():
        os.environ[k] = v
