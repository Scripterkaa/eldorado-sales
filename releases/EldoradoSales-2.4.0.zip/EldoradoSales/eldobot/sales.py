"""Numbers behind the sales dashboard.

User rule (2026-11-11): sales are counted on the day the order was DELIVERED (stateLogs
"Delivered"), not when it was received/completed. Canceled orders are not sales.
Input is the slim order dicts kept by history.OrderHistory.
"""
from __future__ import annotations

from collections import defaultdict
from datetime import date, datetime, timedelta

from .buyers import range_customers
from .history import DISPUTE_STATES, NOT_SALES
from .util import parse_dt

TOP_OFFERS = 8


def _sales(orders, tz):
    """(local delivery datetime, order) for every order that counts as a sale."""
    out = []
    for o in orders:
        if o.get("delivered") and o.get("state") not in NOT_SALES:
            out.append((parse_dt(o["delivered"]).astimezone(tz), o))
    return out


def _sum(rows) -> tuple[int, float]:
    return len(rows), round(sum(o["total"] for _, o in rows), 2)


def _between(sales, start: datetime, end: datetime):
    return [(t, o) for t, o in sales if start <= t < end]


def _pct(now: float, before: float) -> float | None:
    return None if before <= 0 else round((now - before) / before * 100, 1)


def _kpi(label, sales, start, end, cmp_label, cmp_start, cmp_end, rate):
    n, gross = _sum(_between(sales, start, end))
    cn, cgross = _sum(_between(sales, cmp_start, cmp_end))
    return {
        "label": label, "orders": n, "gross": gross,
        "net": round(gross * (1 - rate), 2) if rate is not None else None,
        "cmp_label": cmp_label, "cmp_orders": cn, "cmp_gross": cgross, "delta_pct": _pct(gross, cgross),
    }


def _month_start(d: date) -> date:
    return d.replace(day=1)


def _same_moment_last_month(now: datetime) -> datetime:
    first_this = now.replace(day=1)
    last_prev = first_this - timedelta(days=1)
    return now.replace(year=last_prev.year, month=last_prev.month, day=min(now.day, last_prev.day))


def _midnight(d: date, tz) -> datetime:
    return datetime(d.year, d.month, d.day, tzinfo=tz)


def _offers(rows) -> list[dict]:
    agg: dict[str, list] = defaultdict(lambda: [0, 0.0])
    for _, o in rows:
        a = agg[o["title"]]
        a[0] += 1
        a[1] += o["total"]
    total = sum(v[1] for v in agg.values()) or 1.0
    items = sorted(agg.items(), key=lambda kv: -kv[1][1])
    out = [{"title": t, "orders": n, "gross": round(g, 2), "share": round(g / total * 100, 1)}
           for t, (n, g) in items[:TOP_OFFERS]]
    rest = items[TOP_OFFERS:]
    if rest:
        g = sum(v[1] for _, v in rest)
        out.append({"title": f"อื่นๆ ({len(rest)} รายการ)", "orders": sum(v[0] for _, v in rest),
                    "gross": round(g, 2), "share": round(g / total * 100, 1)})
    return out


def _hours(rows) -> list[dict]:
    h = [[0, 0.0] for _ in range(24)]
    for t, o in rows:
        h[t.hour][0] += 1
        h[t.hour][1] += o["total"]
    return [{"hour": i, "orders": n, "gross": round(g, 2)} for i, (n, g) in enumerate(h)]


def _order_row(o, tz) -> dict:
    created = parse_dt(o["created"]).astimezone(tz)
    delivered = parse_dt(o["delivered"]).astimezone(tz) if o.get("delivered") else None
    return {
        "id": o.get("id"),
        "created": created.isoformat(), "delivered": delivered.isoformat() if delivered else None,
        "title": o["title"], "total": o["total"], "qty": o.get("qty", 1), "state": o.get("state"),
        "buyer": o.get("buyer", ""), "dispute": o.get("dispute", ""), "review": o.get("review"),
    }


def dashboard(orders: dict, now: datetime, tz, days: int, rate: float | None,
              covered_from: datetime | None = None) -> dict:
    """Everything the main screen shows, for the last `days` days (today included).
    Days the order cache does not fully cover yet are flagged loaded=False and left out of averages."""
    now_l = now.astimezone(tz)
    today = now_l.date()
    sales = _sales(orders.values(), tz)
    t0 = _midnight(today, tz)

    kpis = [
        _kpi("วันนี้", sales, t0, now_l, "เมื่อวานเวลาเดียวกัน", t0 - timedelta(days=1), now_l - timedelta(days=1), rate),
        _kpi("เมื่อวาน", sales, t0 - timedelta(days=1), t0, "วันก่อนหน้า", t0 - timedelta(days=2),
             t0 - timedelta(days=1), rate),
        _kpi("7 วันที่ผ่านมา", sales, t0 - timedelta(days=7), t0, "7 วันก่อนหน้า", t0 - timedelta(days=14),
             t0 - timedelta(days=7), rate),
        _kpi("เดือนนี้", sales, _midnight(_month_start(today), tz), now_l, "เดือนที่แล้วช่วงเดียวกัน",
             _midnight(_month_start(_same_moment_last_month(now_l).date()), tz), _same_moment_last_month(now_l), rate),
    ]

    first = today - timedelta(days=days - 1)
    range_rows = _between(sales, _midnight(first, tz), now_l + timedelta(seconds=1))
    by_day: dict[date, list] = defaultdict(list)
    for t, o in range_rows:
        by_day[t.date()].append((t, o))
    problems_by_day: dict[date, list] = defaultdict(lambda: [0, 0])
    for o in orders.values():
        if not o.get("delivered"):
            continue
        d = parse_dt(o["delivered"]).astimezone(tz).date()
        if o.get("state") in DISPUTE_STATES:
            problems_by_day[d][0] += 1
        elif o.get("state") in NOT_SALES:
            problems_by_day[d][1] += 1

    complete_after = covered_from.astimezone(tz).date() if covered_from else None  # that day itself is partial
    daily = []
    for i in range(days):
        d = first + timedelta(days=i)
        n, gross = _sum(by_day.get(d, []))
        daily.append({
            "date": d.isoformat(), "orders": n, "gross": gross,
            "net": round(gross * (1 - rate), 2) if rate is not None else None,
            "disputed": problems_by_day[d][0], "canceled": problems_by_day[d][1], "partial": d == today,
            "loaded": complete_after is None or d > complete_after,
        })
    full_days = [x for x in daily if not x["partial"] and x["loaded"]] or [x for x in daily if x["loaded"]] or daily
    best = max(daily, key=lambda x: x["gross"]) if daily else None
    missing = sum(not x["loaded"] for x in daily)

    weekday = [[0.0, 0] for _ in range(7)]  # gross sum, number of such days (complete days only)
    for x in full_days:
        wd = date.fromisoformat(x["date"]).weekday()
        weekday[wd][0] += x["gross"]
        weekday[wd][1] += 1

    n, gross = _sum(range_rows)
    recent = sorted(orders.values(), key=lambda o: o["created"], reverse=True)[:25]
    since = now - timedelta(days=30)
    attention = [o for o in orders.values()
                 if o.get("state") in DISPUTE_STATES | {"Paid"} and parse_dt(o["created"]) >= since]
    attention.sort(key=lambda o: o["created"], reverse=True)
    return {
        "now": now_l.isoformat(), "tz": str(tz), "days": days, "fee_rate": rate,
        "kpis": kpis,
        "range": {
            "first": first.isoformat(), "last": today.isoformat(), "orders": n, "gross": gross,
            "net": round(gross * (1 - rate), 2) if rate is not None else None,
            "avg_day": round(sum(x["gross"] for x in full_days) / max(1, len(full_days)), 2),
            "avg_orders": round(sum(x["orders"] for x in full_days) / max(1, len(full_days)), 1),
            "best": best,
            "avg_ticket": round(gross / n, 2) if n else 0,
            "missing_days": missing,
        },
        "daily": daily,
        "offers": _offers(range_rows),
        "hours": _hours(range_rows),
        "weekdays": [{"weekday": i, "avg": round(s / c, 2) if c else 0, "days": c} for i, (s, c) in enumerate(weekday)],
        "recent": [_order_row(o, tz) for o in recent],
        "attention": [_order_row(o, tz) for o in attention[:20]],
        "customers": range_customers(orders, range_rows, tz),
    }


def day_detail(orders: dict, day: date, tz, rate: float | None) -> dict:
    sales = _sales(orders.values(), tz)
    start = _midnight(day, tz)
    rows = _between(sales, start, start + timedelta(days=1))
    prev = _between(sales, start - timedelta(days=1), start)
    n, gross = _sum(rows)
    pn, pgross = _sum(prev)
    listed = [o for o in orders.values()
              if o.get("delivered") and parse_dt(o["delivered"]).astimezone(tz).date() == day]
    listed.sort(key=lambda o: o["delivered"], reverse=True)
    return {
        "date": day.isoformat(), "orders": n, "gross": gross,
        "net": round(gross * (1 - rate), 2) if rate is not None else None,
        "prev_orders": pn, "prev_gross": pgross, "delta_pct": _pct(gross, pgross),
        "avg_ticket": round(gross / n, 2) if n else 0,
        "offers": _offers(rows), "hours": _hours(rows),
        "list": [_order_row(o, tz) for o in listed],
        "disputed": sum(o.get("state") in DISPUTE_STATES for o in listed),
        "canceled": sum(o.get("state") in NOT_SALES for o in listed),
    }


def sync_days_needed(range_days: int, now: datetime, tz) -> int:
    """Cache depth so every KPI (incl. 'this month vs last month') can be computed."""
    today = now.astimezone(tz).date()
    last_month_start = _month_start(_month_start(today) - timedelta(days=1))
    return max(range_days, (today - last_month_start).days + 1, 15) + 1
