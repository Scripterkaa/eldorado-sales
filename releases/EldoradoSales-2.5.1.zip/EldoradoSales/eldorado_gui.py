"""Eldorado Sales - desktop dashboard (v2).

Starts a private local server (127.0.0.1) and opens the dashboard in its own window
(Microsoft Edge "app" mode: no tabs or address bar). Closing the window quits the app.

  pythonw eldorado_gui.py              open the app (or focus the running one)
  python  eldorado_gui.py --serve-only print the URL and keep serving (for testing)

The previous tkinter version (with price tools) lives in legacy/. This app never edits prices.
"""
from __future__ import annotations

import json
import os
import secrets
import socket
import subprocess
import sys
import threading
import time
import webbrowser
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from eldobot.config import ROOT  # noqa: E402
from eldobot.util import add_log_listener, log  # noqa: E402
from eldobot.version import APP_VERSION  # noqa: E402
from eldobot.webapp import SalesService, serve  # noqa: E402

PORT = 47615                      # fixed so a second launch finds the running app
SESSION_FILE = ROOT / "data" / "app_session.json"
LOG_FILE = ROOT / "data" / "app.log"
HEARTBEAT_TIMEOUT = 180           # seconds without the window pinging -> quit (minimised windows ping slowly)
EDGE_PATHS = [
    Path(os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)")) / "Microsoft/Edge/Application/msedge.exe",
    Path(os.environ.get("PROGRAMFILES", r"C:\Program Files")) / "Microsoft/Edge/Application/msedge.exe",
]


def _file_logger() -> None:
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    if LOG_FILE.exists() and LOG_FILE.stat().st_size > 2_000_000:
        LOG_FILE.replace(LOG_FILE.with_suffix(".old.log"))
    lock = threading.Lock()

    def write(ts, tag, text):
        with lock, LOG_FILE.open("a", encoding="utf-8") as fh:
            fh.write(f"{time.strftime('%Y-%m-%d')} {ts} [{tag}] {text}\n")
    add_log_listener(write)


def _port_free(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(("127.0.0.1", port)) != 0


def open_window(url: str):
    """Open the dashboard as an app window. Returns the Edge process (or None for a normal browser)."""
    edge = next((p for p in EDGE_PATHS if p.exists()), None)
    if edge is None:
        webbrowser.open(url)
        return None
    profile = ROOT / "data" / "edge-app-profile"
    return subprocess.Popen([
        str(edge), f"--app={url}", f"--user-data-dir={profile}", "--window-size=1480,960",
        "--no-first-run", "--no-default-browser-check", "--disable-background-mode",
        "--disable-features=Translate,msEdgeSidebarV2", "--hide-crash-restore-bubble",
    ])


def main() -> None:
    global PORT
    serve_only = "--serve-only" in sys.argv
    reuse_token = None
    if "--port" in sys.argv:  # for testing a second copy next to a running app
        PORT = int(sys.argv[sys.argv.index("--port") + 1])
    if "--reuse" in sys.argv:  # restart after an in-app update: same port + token, the open window just reloads
        i = sys.argv.index("--reuse")
        PORT, reuse_token = int(sys.argv[i + 1]), sys.argv[i + 2]
    if reuse_token is None and not _port_free(PORT):
        # already running: just open another window onto it
        try:
            s = json.loads(SESSION_FILE.read_text(encoding="utf-8"))
            open_window(f"http://127.0.0.1:{s['port']}/?t={s['token']}")
            return
        except (OSError, ValueError, KeyError):
            pass  # stale: fall through and fail loudly on bind

    _file_logger()
    token = reuse_token or secrets.token_urlsafe(24)
    service = SalesService()
    httpd = serve(service, token, PORT)
    SESSION_FILE.write_text(json.dumps({"port": PORT, "token": token, "pid": os.getpid()}), encoding="utf-8")
    url = f"http://127.0.0.1:{PORT}/?t={token}"
    log("app", f"dashboard v{APP_VERSION} at http://127.0.0.1:{PORT}/")
    if "--bot" in sys.argv:  # the bot was running before the update
        try:
            service.bot_start()
        except Exception as exc:  # noqa: BLE001
            log("error", f"bot restart failed: {exc}")

    service.last_heartbeat = time.time()
    if serve_only:
        print(url, flush=True)
        try:
            while not service.restart_requested.wait(1):
                pass
        except KeyboardInterrupt:
            pass
    else:
        proc = None if reuse_token else open_window(url)  # after an update the old window stays open
        while not service.restart_requested.wait(2):
            if proc is not None and proc.poll() is not None:
                break  # window closed
            if time.time() - service.last_heartbeat > HEARTBEAT_TIMEOUT:
                break  # window gone without the process telling us

    restart = service.restart_requested.is_set()
    bot_running = service.bot_status()["running"]
    service.bot_stop(wait=restart)
    httpd.shutdown()
    httpd.server_close()
    if restart:
        args = [sys.executable, str(Path(__file__).resolve()), "--reuse", str(PORT), token]
        args += ["--serve-only"] if serve_only else []
        args += ["--bot"] if bot_running else []
        flags = 0x00000008 | 0x00000200 if os.name == "nt" else 0  # DETACHED_PROCESS | NEW_PROCESS_GROUP
        subprocess.Popen(args, cwd=str(ROOT), creationflags=flags, close_fds=True)
        log("app", "restarting into the updated version")
        return
    try:
        SESSION_FILE.unlink()
    except OSError:
        pass
    log("app", "closed")


if __name__ == "__main__":
    main()
