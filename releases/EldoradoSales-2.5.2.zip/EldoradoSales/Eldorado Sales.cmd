@echo off
rem Opens the Eldorado Sales app (run install.cmd once first).
if not exist "%~dp0.venv\Scripts\pythonw.exe" (
  echo Not installed yet - running install.cmd first...
  call "%~dp0install.cmd"
  exit /b
)
start "" "%~dp0.venv\Scripts\pythonw.exe" "%~dp0eldorado_gui.py"
