"use strict";
/* Eldorado Sales dashboard. Sales are counted by delivery day. This app never edits prices. */

const TOKEN = new URLSearchParams(location.search).get("t") || "";
const $ = (s, el = document) => el.querySelector(s);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const TH_MONTHS = ["ม.ค.", "ก.พ.", "มี.ค.", "เม.ย.", "พ.ค.", "มิ.ย.", "ก.ค.", "ส.ค.", "ก.ย.", "ต.ค.", "พ.ย.", "ธ.ค."];
const TH_DAY_SHORT = ["จ.", "อ.", "พ.", "พฤ.", "ศ.", "ส.", "อา."];          // Monday first
const TH_DAY = ["จันทร์", "อังคาร", "พุธ", "พฤหัสบดี", "ศุกร์", "เสาร์", "อาทิตย์"];
const STATES = {
  Paid: ["รอส่งของ", "b-paid"], Delivered: ["ส่งแล้ว", "b-delivered"], Received: ["ลูกค้ารับแล้ว", "b-received"],
  Completed: ["จบแล้ว", "b-completed"], Disputed: ["ข้อพิพาท", "b-dispute"], DeliveredDisputed: ["ข้อพิพาท", "b-dispute"],
  Canceled: ["ยกเลิก", "b-canceled"], PendingReview: ["รอตรวจ", "b-paid"], Initialized: ["เริ่มต้น", "b-canceled"],
};

const store = {
  get(k, d) { try { return localStorage.getItem(k) ?? d; } catch { return d; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch { /* private mode */ } },
};
const state = { days: +store.get("days", 30), data: null, syncing: false, openDay: null, notes: {}, stock: null, chats: [] };

/* ------------------------------------------------------------------ helpers */
async function api(path, body) {
  const opts = { headers: { "X-Token": TOKEN } };
  if (body !== undefined) {
    opts.method = "POST";
    opts.headers["Content-Type"] = "application/json";
    opts.body = JSON.stringify(body);
  }
  const r = await fetch(path, opts);
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || `HTTP ${r.status}`);
  return j;
}
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const money = (v, d = 2) => "$" + Number(v || 0).toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d });
const moneyShort = (v) => (v >= 1000 ? "$" + (v / 1000).toFixed(v >= 10000 ? 0 : 1) + "k" : "$" + Math.round(v));
const int = (v) => Number(v || 0).toLocaleString("en-US");
const parseDay = (s) => { const [y, m, d] = s.split("-").map(Number); return new Date(y, m - 1, d); };
const wd = (date) => (date.getDay() + 6) % 7;
const dayShort = (s) => { const d = parseDay(s); return `${d.getDate()} ${TH_MONTHS[d.getMonth()]}`; };
const dayLong = (s) => { const d = parseDay(s); return `วัน${TH_DAY[wd(d)]}ที่ ${d.getDate()} ${TH_MONTHS[d.getMonth()]} ${d.getFullYear()}`; };
const hhmm = (iso) => (iso ? iso.slice(11, 16) : "—");
const ddmm = (iso) => (iso ? `${iso.slice(8, 10)}/${iso.slice(5, 7)}` : "");
const badge = (st) => { const [t, c] = STATES[st] || [st || "?", "b-canceled"]; return `<span class="badge ${c}">${esc(t)}</span>`; };
const cleanTitle = (t) => String(t || "").replace(/\s*\|\s*[^|]*instant delivery[^|]*$/i, "").replace(/\s{2,}/g, " ").trim();

function delta(pct) {
  if (pct === null || pct === undefined) return `<span class="delta flat">—</span>`;
  if (Math.abs(pct) < 0.05) return `<span class="delta flat">0%</span>`;
  return pct > 0 ? `<span class="delta up">▲ ${pct.toFixed(1)}%</span>` : `<span class="delta down">▼ ${Math.abs(pct).toFixed(1)}%</span>`;
}
function niceMax(v) {
  if (v <= 0) return 4;
  const mag = 10 ** Math.floor(Math.log10(v / 4));
  for (const s of [1, 2, 2.5, 5, 10]) if (s * mag * 4 >= v) return s * mag * 4;
  return 40 * mag;
}
function barPath(x, y, w, h, r) {
  r = Math.max(0, Math.min(r, w / 2, h));
  return `M${x},${y + h}L${x},${y + r}Q${x},${y} ${x + r},${y}L${x + w - r},${y}Q${x + w},${y} ${x + w},${y + r}L${x + w},${y + h}Z`;
}

/* ------------------------------------------------------------------ tooltip/toast */
const tip = $("#tooltip");
function showTip(e, html) {
  tip.innerHTML = html;
  tip.classList.add("show");
  const r = tip.getBoundingClientRect();
  let x = e.clientX + 16, y = e.clientY - r.height - 12;
  if (x + r.width > innerWidth - 10) x = e.clientX - r.width - 16;
  if (y < 10) y = e.clientY + 18;
  tip.style.left = x + "px";
  tip.style.top = y + "px";
}
const hideTip = () => tip.classList.remove("show");
let toastTimer;
function toast(msg, err = false) {
  const t = $("#toast");
  t.textContent = msg;
  t.className = "toast show" + (err ? " err" : "");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove("show"), 3800);
}

/* ------------------------------------------------------------------ KPIs */
function renderKpis(kpis) {
  $("#kpis").innerHTML = kpis.map((k, i) => `
    <div class="kpi ${i === 0 ? "hero" : ""}">
      <div class="kpi-top"><span class="kpi-label">${esc(k.label)}</span>${delta(k.delta_pct)}</div>
      <div class="kpi-value">${money(k.gross)}</div>
      <div class="kpi-sub"><b>${int(k.orders)}</b> ออเดอร์${k.net != null ? ` · Net ≈ <b>${money(k.net)}</b>` : ""}</div>
      <div class="kpi-cmp">${esc(k.cmp_label)} ${money(k.cmp_gross)} · ${int(k.cmp_orders)} ออเดอร์</div>
    </div>`).join("");
}

/* ------------------------------------------------------------------ daily chart */
function renderDaily(el, daily, avg, onPick, selected) {
  const W = el.clientWidth, H = el.clientHeight;
  if (!daily.length || W < 50) { el.innerHTML = `<div class="empty">ยังไม่มีข้อมูล</div>`; return; }
  const pl = 52, pr = 12, pt = 22, pb = 30;
  const top = niceMax(Math.max(...daily.map((d) => d.gross), avg || 0, 1) * 1.08);
  const ph = H - pt - pb, n = daily.length, slot = (W - pl - pr) / n;
  const bw = Math.max(2, Math.min(40, slot * 0.66));
  const y = (v) => pt + ph * (1 - v / top);
  let s = `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
    <defs>
      <linearGradient id="gGold" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:var(--bar-top)"/><stop offset="1" style="stop-color:var(--bar-bottom)"/></linearGradient>
      <linearGradient id="gSel" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:var(--sel-top)"/><stop offset="1" style="stop-color:var(--sel-bottom)"/></linearGradient>
      <pattern id="hatch" width="7" height="7" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
        <rect width="7" height="7" style="fill:var(--hatch-bg)"/><line x1="0" y1="0" x2="0" y2="7" style="stroke:var(--hatch-line)" stroke-width="2.4"/></pattern>
    </defs>`;
  for (let i = 0; i <= 4; i++) {
    const v = (top * i) / 4, yy = y(v);
    s += `<line class="gridline" x1="${pl}" x2="${W - pr}" y1="${yy}" y2="${yy}"/>`;
    s += `<text class="axis-label" x="${pl - 10}" y="${yy + 4}" text-anchor="end">${moneyShort(v)}</text>`;
  }
  const every = Math.max(1, Math.ceil(n / Math.max(4, Math.floor((W - pl) / 64))));
  daily.forEach((d, i) => {
    const x = pl + slot * i + (slot - bw) / 2, by = y(d.gross), bh = Math.max(0, pt + ph - by);
    const fill = d.date === selected ? "url(#gSel)" : d.partial ? "url(#hatch)" : "url(#gGold)";
    if (d.loaded === false) {
      s += `<path d="${barPath(x, pt + ph * 0.55, bw, ph * 0.45, 6)}" style="fill:var(--ghost-bar);stroke:var(--ghost-line)" stroke-dasharray="3 3"/>`;
    } else if (bh > 0) s += `<path id="bar${i}" class="bar" d="${barPath(x, by, bw, bh, 6)}" fill="${fill}"/>`;
    if (n <= 16 && d.gross > 0) s += `<text x="${x + bw / 2}" y="${by - 7}" text-anchor="middle" style="fill:var(--text-2)" font-size="11">${moneyShort(d.gross)}</text>`;
    const dt = parseDay(d.date);
    if (i % every === 0 || d.date === selected) {
      const lab = i === 0 || dt.getDate() === 1 ? `${dt.getDate()} ${TH_MONTHS[dt.getMonth()]}` : `${dt.getDate()}`;
      const col = d.date === selected ? "var(--sel-bottom)" : wd(dt) >= 5 ? "var(--muted)" : "var(--faint)";
      s += `<text x="${x + bw / 2}" y="${H - 9}" text-anchor="middle" font-size="11" style="fill:${col}">${lab}</text>`;
    }
    s += `<rect class="hit" data-i="${i}" x="${pl + slot * i}" y="${pt}" width="${slot}" height="${ph}" fill="transparent" style="cursor:pointer"/>`;
  });
  if (avg > 0) {
    const ay = y(avg);
    s += `<line x1="${pl}" x2="${W - pr}" y1="${ay}" y2="${ay}" style="stroke:var(--avg-line)" stroke-dasharray="5 5" stroke-width="1.4"/>`;
    s += `<rect x="${W - pr - 104}" y="${ay - 21}" width="104" height="18" rx="6" style="fill:var(--avg-bg);stroke:var(--line)"/>`;
    s += `<text x="${W - pr - 52}" y="${ay - 8}" text-anchor="middle" font-size="11" style="fill:var(--second-2)">เฉลี่ย ${moneyShort(avg)}/วัน</text>`;
  }
  el.innerHTML = s + "</svg>";
  el.querySelectorAll(".hit").forEach((h) => {
    const i = +h.dataset.i, d = daily[i], bar = el.querySelector(`#bar${i}`);
    h.addEventListener("mousemove", (e) => {
      if (d.loaded === false) {
        showTip(e, `<div class="t-title">${dayLong(d.date)}</div><div class="t-hint">ยังไม่ได้โหลดออเดอร์ของวันนี้ — รอสักครู่หรือกด ⟳</div>`);
        return;
      }
      if (bar) bar.style.filter = "brightness(1.18)";
      showTip(e, `<div class="t-title">${dayLong(d.date)}${d.partial ? " (ยังไม่จบวัน)" : ""}</div>
        <div class="t-row">ยอดขาย <b>${money(d.gross)}</b></div>
        <div class="t-row">ออเดอร์ <b>${int(d.orders)}</b></div>
        ${d.net != null ? `<div class="t-row">Net ≈ <b>${money(d.net)}</b></div>` : ""}
        ${d.disputed ? `<div class="t-row">ข้อพิพาท <b style="color:var(--red)">${d.disputed}</b></div>` : ""}
        ${d.canceled ? `<div class="t-row">ยกเลิก (ไม่นับ) <b>${d.canceled}</b></div>` : ""}
        <div class="t-hint">คลิกเพื่อดูรายละเอียด</div>`);
    });
    h.addEventListener("mouseleave", () => { if (bar) bar.style.filter = ""; hideTip(); });
    h.addEventListener("click", () => { hideTip(); if (d.loaded !== false && onPick) onPick(d.date); });
  });
}

/* ------------------------------------------------------------------ hours chart */
function renderHours(el, hours) {
  const W = el.clientWidth, H = el.clientHeight;
  const total = hours.reduce((a, h) => a + h.gross, 0);
  if (!total || W < 50) { el.innerHTML = `<div class="empty">ยังไม่มีข้อมูล</div>`; return null; }
  const pl = 6, pr = 6, pt = 10, pb = 22, ph = H - pt - pb;
  const max = Math.max(...hours.map((h) => h.gross));
  const peak = hours.reduce((a, h) => (h.gross > a.gross ? h : a), hours[0]);
  const slot = (W - pl - pr) / 24, bw = Math.max(3, slot * 0.7);
  let s = `<svg width="${W}" height="${H}">`;
  hours.forEach((h, i) => {
    const bh = max ? (ph * h.gross) / max : 0, x = pl + slot * i + (slot - bw) / 2, y = pt + ph - bh;
    const style = h.hour === peak.hour ? "fill:var(--peak)" : `fill:var(--second);fill-opacity:${(0.28 + 0.62 * (h.gross / max)).toFixed(2)}`;
    if (bh > 0) s += `<path d="${barPath(x, y, bw, bh, 4)}" style="${style}"/>`;
    if (i % 3 === 0) s += `<text x="${x + bw / 2}" y="${H - 6}" text-anchor="middle" font-size="10.5" style="fill:var(--faint)">${String(i).padStart(2, "0")}</text>`;
    s += `<rect class="hit" data-i="${i}" x="${pl + slot * i}" y="${pt}" width="${slot}" height="${ph}" fill="transparent"/>`;
  });
  el.innerHTML = s + "</svg>";
  el.querySelectorAll(".hit").forEach((r) => {
    const h = hours[+r.dataset.i];
    r.addEventListener("mousemove", (e) => showTip(e, `<div class="t-title">${String(h.hour).padStart(2, "0")}:00 – ${String((h.hour + 1) % 24).padStart(2, "0")}:00</div>
      <div class="t-row">ยอดขาย <b>${money(h.gross)}</b></div><div class="t-row">ออเดอร์ <b>${int(h.orders)}</b></div>
      <div class="t-row">สัดส่วน <b>${((h.gross / total) * 100).toFixed(1)}%</b></div>`));
    r.addEventListener("mouseleave", hideTip);
  });
  return peak;
}

/* ------------------------------------------------------------------ lists */
function renderOffers(el, offers) {
  if (!offers.length) { el.innerHTML = `<div class="empty">ยังไม่มียอดขาย</div>`; return; }
  const max = Math.max(...offers.map((o) => o.gross));
  el.innerHTML = offers.map((o, i) => `
    <div class="offer" title="${esc(o.title)}">
      <span class="rank">${i + 1}</span>
      <span class="name">${esc(cleanTitle(o.title))}</span>
      <span class="val">${money(o.gross)}</span>
      <div class="meta"><div class="track"><div class="fill" style="width:${(o.gross / max) * 100}%"></div></div>
        <span class="pct">${int(o.orders)} ออเดอร์ · ${o.share}%</span></div>
    </div>`).join("");
}

function renderWeek(el, weekdays) {
  const max = Math.max(...weekdays.map((w) => w.avg), 1);
  const best = weekdays.reduce((a, w) => (w.avg > a.avg ? w : a), weekdays[0]);
  el.innerHTML = weekdays.map((w) => `
    <div class="wk ${w === best && w.avg > 0 ? "best" : ""}" title="${w.days} วันในช่วงที่เลือก">
      <span class="lab">${TH_DAY_SHORT[w.weekday]}</span>
      <div class="track"><div class="fill" style="width:${(w.avg / max) * 100}%"></div></div>
      <span class="v">${w.days ? money(w.avg, 0) : "—"}</span>
    </div>`).join("");
}

function renderRangeStats(d) {
  const r = d.range;
  $("#rangeLabel").textContent = `${dayShort(r.first)} – ${dayShort(r.last)}`;
  const stats = [
    ["ยอดขายรวม", money(r.gross), r.net != null ? `Net ≈ ${money(r.net)}` : ""],
    ["ออเดอร์ทั้งหมด", int(r.orders), `${r.avg_orders} ออเดอร์/วัน`],
    ["เฉลี่ยต่อวัน", money(r.avg_day), "ไม่นับวันนี้"],
    ["ต่อออเดอร์", money(r.avg_ticket), "ราคาเฉลี่ย"],
    ["วันที่ขายดีสุด", r.best ? money(r.best.gross) : "—", r.best ? dayShort(r.best.date) : ""],
    ["ค่าธรรมเนียม", d.fee_rate != null ? (d.fee_rate * 100).toFixed(1) + "%" : "—", "จาก 30 วันล่าสุด"],
  ];
  $("#rangeStats").innerHTML = stats.map(([l, v, s]) => `<div class="stat"><div class="l">${l}</div><div class="v">${v}</div><div class="s">${esc(s)}</div></div>`).join("");
}

const TAGS = { vip: ["⭐", "VIP", "tag-vip"], watch: ["⚠", "ระวัง", "tag-watch"], bad: ["⛔", "มีปัญหา", "tag-bad"] };
const tagIcons = (name) => {
  const e = state.notes?.[String(name || "").trim().toLowerCase()];
  if (!e) return "";
  return (e.tags || []).filter((t) => TAGS[t]).map((t) => `<span class="tag-icon ${TAGS[t][2]}" title="${TAGS[t][1]}${e.note ? " — " + esc(e.note) : ""}">${TAGS[t][0]}</span>`).join("") +
    (e.note && !(e.tags || []).length ? `<span class="tag-icon" title="${esc(e.note)}">📝</span>` : "");
};
const buyerLink = (name) => (name ? `<a class="buyer-link" data-buyer="${esc(name)}" title="ดูประวัติการซื้อของ ${esc(name)}">${esc(name)}</a>${tagIcons(name)}` : "");
const ICON_COPY = `<svg viewBox="0 0 24 24"><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/></svg>`;
const ICON_OPEN = `<svg viewBox="0 0 24 24"><path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/></svg>`;
const ICON_OK = `<svg viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>`;
function orderId(id) {
  if (!id) return `<span class="muted">—</span>`;
  return `<span class="oid-wrap"><span class="oid" title="${esc(id)}">#${esc(id.slice(0, 8))}</span>` +
    `<button class="mini" data-copy="${esc(id)}" title="คัดลอกเลขออเดอร์ (${esc(id)})">${ICON_COPY}</button>` +
    `<button class="mini" data-open-order="${esc(id)}" title="เปิดออเดอร์นี้บน Eldorado">${ICON_OPEN}</button></span>`;
}
async function copyText(text) {
  try { await navigator.clipboard.writeText(text); return true; } catch { /* fall back below */ }
  const ta = Object.assign(document.createElement("textarea"), { value: text });
  ta.style.cssText = "position:fixed;opacity:0";
  document.body.appendChild(ta);
  ta.select();
  const ok = document.execCommand("copy");
  ta.remove();
  return ok;
}

function ordersTable(rows, timeKey, timeLabel, showBuyer = true) {
  if (!rows.length) return `<tr><td class="muted">ยังไม่มีออเดอร์</td></tr>`;
  return `<thead><tr><th>${timeLabel}</th><th>เลขออเดอร์</th><th>สินค้า</th><th style="text-align:right">ยอด</th>${showBuyer ? "<th>ผู้ซื้อ</th>" : ""}<th>สถานะ</th></tr></thead><tbody>` +
    rows.map((o) => `<tr>
      <td class="t">${ddmm(o[timeKey])} ${hhmm(o[timeKey])}</td>
      <td>${orderId(o.id)}</td>
      <td class="title" title="${esc(o.title)}">${esc(cleanTitle(o.title))}${o.qty > 1 ? ` <span class="muted">×${o.qty}</span>` : ""}</td>
      <td class="amt">${money(o.total)}</td>
      ${showBuyer ? `<td class="buyer">${buyerLink(o.buyer)}</td>` : ""}
      <td>${badge(o.state)}${o.dispute && showBuyer === false ? ` <span class="muted">${esc(o.dispute)}</span>` : ""}</td></tr>`).join("") + "</tbody>";
}

function renderAttention(el, rows, flagged = []) {
  const WHY = { watch: `<span class="tag-watch-chip">⚠ ระวัง</span>`, bad: `<span class="tag-bad">⛔ มีปัญหา</span>`,
    dispute_before: `<span class="tag-plain">เคยมีข้อพิพาท</span>` };
  const flagHtml = flagged.length ? `<div class="att-sub">ลูกค้าที่ต้องระวังสั่งซื้อ · 7 วัน</div>` + flagged.slice(0, 8).map((o) => `
    <div class="att watch">
      <div class="top"><span>${buyerLink(o.buyer)}</span><span class="amt">${money(o.total)}</span></div>
      <div class="name" title="${esc(o.title)}">${esc(cleanTitle(o.title))}</div>
      <div class="why">${orderId(o.id)}</div>
      <div class="why">${esc(`${ddmm(o.created)} ${hhmm(o.created)}`)} · ${o.why.map((w) => WHY[w] || "").join(" ")}</div>
    </div>`).join("") + (flagged.length > 8 ? `<div class="muted" style="text-align:center">+ อีก ${flagged.length - 8} ออเดอร์</div>` : "") : "";
  if (!rows.length) {
    el.innerHTML = `<div class="all-clear"><div class="big">✓</div>ไม่มีอะไรค้าง<br><span class="muted">ไม่มีข้อพิพาทหรือออเดอร์ที่รอส่งของ</span></div>` + flagHtml;
    return;
  }
  el.innerHTML = rows.map((o) => `
    <div class="att ${o.state === "Paid" ? "paid" : ""}">
      <div class="top">${badge(o.state)}<span class="amt">${money(o.total)}</span></div>
      <div class="name" title="${esc(o.title)}">${esc(cleanTitle(o.title))}</div>
      <div class="why">${orderId(o.id)}</div>
      <div class="why">${esc(`${ddmm(o.created)} ${hhmm(o.created)}`)}${o.buyer ? " · " + buyerLink(o.buyer) : ""}${o.dispute ? " · " + esc(o.dispute) : ""}</div>
    </div>`).join("") + flagHtml;
}

/* ------------------------------------------------------------------ stock */
function renderStock(s) {
  const el = $("#stockTable");
  if (!s || s.error) { el.innerHTML = `<tr><td class="muted">${esc(s?.error || "กำลังโหลด…")}</td></tr>`; return; }
  const showPaused = $("#showPaused").checked;
  const paused = s.rows.filter((r) => r.state !== "Active").length;
  $("#pausedCount").textContent = paused ? `(${paused})` : "";
  $("#stockHint").textContent = `ขาย/วัน เฉลี่ย ${s.rate_days} วันล่าสุด · เตือนเมื่อเหลือ ≤ ${s.min_qty} ชิ้น หรือพอขายไม่ถึง ${s.min_days} วัน${s.alerts ? " (แจ้ง Discord เปิดอยู่)" : ""}`;
  const rows = s.rows.filter((r) => showPaused || r.state === "Active");
  if (!rows.length) { el.innerHTML = `<tr><td class="muted">ไม่มี offer ที่เปิดขายอยู่</td></tr>`; return; }
  el.innerHTML = `<thead><tr><th>สินค้า</th><th>สต็อก</th><th style="text-align:right">ขาย/วัน</th><th style="text-align:right">วันนี้</th><th>พอขายอีก</th></tr></thead><tbody>` +
    rows.map((r) => {
      const cover = r.per_day > 0 ? Math.min(100, (r.stock / (r.per_day * 7)) * 100) : 100;
      const lvl = r.state !== "Active" ? "off" : r.low ? "low" : r.days_left !== null && r.days_left < s.min_days * 2 ? "mid" : "ok";
      const days = r.state !== "Active" ? "ปิดขายอยู่" : r.days_left === null ? "ยังไม่มียอดขาย" :
        r.days_left < 1 ? `~${Math.max(1, Math.round(r.days_left * 24))} ชม.` : `~${r.days_left} วัน`;
      return `<tr class="${r.state !== "Active" ? "dimrow" : ""}">
        <td class="title" title="${esc(r.title)}">${esc(cleanTitle(r.title))}</td>
        <td><div class="stockcell"><b>${int(r.stock)}</b><div class="track"><div class="fill lvl-${lvl}" style="width:${cover}%"></div></div></div></td>
        <td class="amt">${r.per_day || "—"}</td>
        <td class="amt dim">${int(r.today)}</td>
        <td><span class="days lvl-${lvl}">${days}</span></td></tr>`;
    }).join("") + "</tbody>";
}
async function loadStock(force = false) {
  try { state.stock = await api(`/api/stock${force ? "?force=1" : ""}`); }
  catch (e) { state.stock = { error: e.message }; }
  renderStock(state.stock);
}
$("#showPaused").addEventListener("change", () => renderStock(state.stock));

/* ------------------------------------------------------------------ chats */
function timeAgo(iso) {
  const mins = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 60000));
  if (mins < 1) return "เมื่อกี้";
  if (mins < 60) return `${mins} นาทีที่แล้ว`;
  if (mins < 60 * 24) return `${Math.round(mins / 60)} ชม.ที่แล้ว`;
  return `${Math.round(mins / 1440)} วันที่แล้ว`;
}
function renderChats(chats) {
  state.chats = chats || [];
  const n = state.chats.length;
  $("#chatCount").hidden = !n;
  $("#chatCount").textContent = n;
  $("#readAllChats").hidden = n < 2;
  document.title = n ? `(${n}) แชทใหม่ · Eldorado Sales` : "Eldorado Sales";
  if (!n) {
    $("#chats").innerHTML = `<div class="all-clear"><div class="big">✓</div>ไม่มีแชทใหม่<br><span class="muted">ลูกค้าทักมาเมื่อไหร่จะขึ้นตรงนี้</span></div>`;
    return;
  }
  $("#chats").innerHTML = state.chats.map((c) => `
    <div class="chat-item">
      <div class="top"><span class="reason-chip">${esc(c.reason_th)}</span><span class="ago" title="${esc(c.at)}">${timeAgo(c.at)}</span></div>
      ${c.message ? `<div class="msg">“${esc(c.message)}”</div>` : ""}
      <div class="why">${buyerLink(c.buyer)} · ${orderId(c.id)}</div>
      <div class="why" title="${esc(c.title)}">${esc(cleanTitle(c.title))} · ${money(c.total)} · ${badge(c.state)}</div>
      <div class="chat-actions">
        <button class="btn sm primary" data-open-chat="${esc(c.id)}">เปิดแชทบน Eldorado</button>
        <button class="btn sm ghost" data-read-chat="${esc(c.id)}">✓ อ่านแล้ว</button>
      </div>
    </div>`).join("");
}
async function markChatsRead(body) {
  try { renderChats((await api("/api/chats/read", body)).chats); }
  catch (e) { toast(e.message, true); }
}
$("#readAllChats").onclick = () => markChatsRead({ all: true });

/* ------------------------------------------------------------------ buyer notes */
async function loadNotes() {
  try { state.notes = await api("/api/notes"); } catch { state.notes = state.notes || {}; }
}
function notesEditor(name) {
  const e = state.notes?.[name.trim().toLowerCase()] || { tags: [], note: "" };
  return `<div class="notes-box" data-notes-for="${esc(name)}">
    <div class="tag-toggles">${Object.entries(TAGS).map(([k, [ic, label, cls]]) =>
      `<button type="button" class="tag-toggle ${cls} ${(e.tags || []).includes(k) ? "on" : ""}" data-tag="${k}">${ic} ${label}</button>`).join("")}</div>
    <textarea class="note-input" rows="2" placeholder="โน้ตส่วนตัว เช่น ชอบซื้อ 10M, เคยขอคืนเงิน… (เก็บในเครื่องนี้เท่านั้น)">${esc(e.note || "")}</textarea>
    <div class="notes-foot"><span class="muted">ติดแท็ก ⚠/⛔ แล้ว ถ้าคนนี้สั่งซื้ออีกจะขึ้นใน "ต้องดู" และแจ้งเตือน Discord</span>
      <button type="button" class="btn sm primary" data-save-notes>บันทึกโน้ต</button></div>
  </div>`;
}
async function saveNotes(box) {
  const name = box.dataset.notesFor;
  const tags = [...box.querySelectorAll(".tag-toggle.on")].map((b) => b.dataset.tag);
  const note = box.querySelector(".note-input").value;
  try {
    const r = await api("/api/notes", { name, tags, note });
    state.notes = r.all;
    toast(tags.length || note.trim() ? "บันทึกโน้ตลูกค้าแล้ว" : "ลบโน้ตแล้ว");
    if (state.data) render();
    const title = $("#dayTitle .who");
    if (title) title.innerHTML = `${avatar(name)}${esc(name)}${tagIcons(name)}`;
  } catch (e) { toast(e.message, true); }
}

/* ------------------------------------------------------------------ main render */
function render() {
  const d = state.data;
  if (!d) return;
  $("#seller").textContent = d.seller ? `ร้าน ${d.seller}` : "ยอดขายร้านคุณ";
  renderKpis(d.kpis);
  const r = d.range;
  $("#rangeSummary").textContent = `${dayShort(r.first)} – ${dayShort(r.last)} · ${int(r.orders)} ออเดอร์ · ${money(r.gross)}` +
    (r.missing_days ? ` · ยังโหลดไม่ครบ ${r.missing_days} วัน` : "");
  renderDaily($("#dailyChart"), d.daily, r.avg_day, openDay, state.openDay);
  $("#offersHint").textContent = `${d.days} วัน`;
  renderOffers($("#offers"), d.offers);
  const peak = renderHours($("#hoursChart"), d.hours);
  $("#peakHour").textContent = peak ? `ขายดีสุด ${String(peak.hour).padStart(2, "0")}:00–${String((peak.hour + 1) % 24).padStart(2, "0")}:00` : "";
  renderWeek($("#weekChart"), d.weekdays);
  renderRangeStats(d);
  $("#recent").innerHTML = ordersTable(d.recent, "created", "เวลาสั่ง");
  renderAttention($("#attention"), d.attention, d.flagged || []);
  if (d.customers) renderCustomers(d.customers, d.days);
  if (d.chats) renderChats(d.chats);
  if (state.stock) renderStock(state.stock);
  renderBot(d.bot);
}

/* ------------------------------------------------------------------ customers */
function avatar(name) {
  let h = 0;
  for (const ch of String(name)) h = (h * 31 + ch.charCodeAt(0)) % 360;
  return `<span class="avatar" style="--h:${h}">${esc(String(name).replace(/^[^A-Za-z0-9ก-๙]+/, "").charAt(0).toUpperCase() || "?")}</span>`;
}
function donut(pct) {
  const r = 52, c = 2 * Math.PI * r, f = (c * Math.max(0, Math.min(100, pct))) / 100;
  return `<svg width="140" height="140" viewBox="0 0 140 140">
    <circle cx="70" cy="70" r="${r}" style="fill:none;stroke:var(--card-3)" stroke-width="14"/>
    <circle cx="70" cy="70" r="${r}" style="fill:none;stroke:var(--accent)" stroke-width="14" stroke-linecap="round"
      stroke-dasharray="${f} ${c}" transform="rotate(-90 70 70)"/></svg>`;
}
function renderCustomers(c, days) {
  $("#topCustomers").innerHTML = c.top.length
    ? `<thead><tr><th>#</th><th>ลูกค้า</th><th style="text-align:right">ซื้อในช่วงนี้</th><th style="text-align:right">ยอด</th><th style="text-align:right">ซื้อทั้งหมด</th><th>ล่าสุด</th></tr></thead><tbody>` +
      c.top.map((b, i) => `<tr>
        <td class="t">${i + 1}</td>
        <td class="who">${avatar(b.name)}${buyerLink(b.name)}${b.lifetime >= 5 ? `<span class="tag-regular">ประจำ</span>` : ""}</td>
        <td class="amt">${int(b.orders)} ครั้ง</td>
        <td class="amt">${money(b.gross)}</td>
        <td class="amt dim">${int(b.lifetime)} ครั้ง</td>
        <td class="t">${ddmm(b.last)} ${hhmm(b.last)}</td></tr>`).join("") + "</tbody>"
    : `<tr><td class="muted">ยังไม่มีชื่อผู้ซื้อ — รออัปเดตสักครู่</td></tr>`;
  $("#returningHint").textContent = `${days} วัน`;
  const pct = c.returning_share ?? 0;
  $("#returning").innerHTML = `
    <div class="donut-wrap">${donut(pct)}<div class="donut-center"><div class="big">${c.returning_share == null ? "—" : pct.toFixed(0) + "%"}</div><div class="muted">ของออเดอร์</div></div></div>
    <p class="ret-note">ออเดอร์ที่มาจาก<b>ลูกค้าที่เคยซื้อกับเรามาก่อน</b></p>
    <div class="ret-stats">
      <div class="stat"><div class="l">ลูกค้าในช่วงนี้</div><div class="v">${int(c.unique)}</div><div class="s">คน</div></div>
      <div class="stat"><div class="l">ซื้อ 2 ครั้งขึ้นไป</div><div class="v">${int(c.repeat_buyers)}</div><div class="s">${c.unique ? ((c.repeat_buyers / c.unique) * 100).toFixed(1) : 0}% ของลูกค้า</div></div>
    </div>`;
}

/* ------------------------------------------------------------------ buyer search (Ctrl+K) */
const pal = { items: [], sel: 0, seq: 0, timer: null };
function highlight(name, q) {
  const i = q ? name.toLowerCase().indexOf(q.toLowerCase()) : -1;
  if (i < 0) return esc(name);
  return esc(name.slice(0, i)) + `<mark>${esc(name.slice(i, i + q.length))}</mark>` + esc(name.slice(i + q.length));
}
function openPalette(q = "") {
  $("#palette").classList.add("show");
  const inp = $("#palInput");
  inp.value = q;
  setTimeout(() => inp.focus(), 0);
  runSearch(q);
}
const closePalette = () => $("#palette").classList.remove("show");
async function runSearch(q) {
  const seq = ++pal.seq;
  try {
    const r = await api(`/api/buyers?q=${encodeURIComponent(q.trim())}`);
    if (seq !== pal.seq) return;
    pal.items = r.results;
    pal.sel = 0;
    $("#palHead").textContent = q.trim()
      ? `พบ ${int(r.total)} คน${r.total > r.results.length ? ` (แสดง ${r.results.length} คนแรก)` : ""}`
      : `ลูกค้าที่ซื้อบ่อยที่สุด · รู้จักทั้งหมด ${int(r.buyers_known)} คน`;
    renderPalette(q.trim());
  } catch (e) {
    $("#palResults").innerHTML = `<div class="empty">${esc(e.message)}</div>`;
  }
}
function renderPalette(q) {
  if (!pal.items.length) {
    $("#palResults").innerHTML = `<div class="empty">ไม่พบผู้ซื้อที่ชื่อมี “${esc(q)}”</div>`;
    return;
  }
  $("#palResults").innerHTML = pal.items.map((b, i) => `
    <div class="pal-item ${i === pal.sel ? "sel" : ""}" data-i="${i}">
      ${avatar(b.name)}
      <div class="pal-main">
        <div class="pal-name">${highlight(b.name, q)}${b.orders >= 5 ? `<span class="tag-regular">ประจำ</span>` : ""}${b.disputes ? `<span class="tag-bad">ข้อพิพาท ${b.disputes}</span>` : ""}</div>
        <div class="pal-sub">ซื้อ ${int(b.orders)} ครั้ง · ${money(b.spent)} · ล่าสุด ${dayShort(b.last.slice(0, 10))}</div>
      </div>
      <span class="pal-go">↵</span>
    </div>`).join("");
  document.querySelectorAll(".pal-item").forEach((el) => {
    el.addEventListener("mousemove", () => { if (pal.sel !== +el.dataset.i) { pal.sel = +el.dataset.i; markSel(); } });
    el.addEventListener("click", () => openBuyer(pal.items[+el.dataset.i].name));
  });
}
function markSel() {
  document.querySelectorAll(".pal-item").forEach((el) => el.classList.toggle("sel", +el.dataset.i === pal.sel));
  const cur = document.querySelector(".pal-item.sel");
  if (cur) cur.scrollIntoView({ block: "nearest" });
}
$("#palInput").addEventListener("input", (e) => {
  clearTimeout(pal.timer);
  pal.timer = setTimeout(() => runSearch(e.target.value), 120);
});
$("#palInput").addEventListener("keydown", (e) => {
  if (e.key === "ArrowDown") { e.preventDefault(); pal.sel = Math.min(pal.items.length - 1, pal.sel + 1); markSel(); }
  else if (e.key === "ArrowUp") { e.preventDefault(); pal.sel = Math.max(0, pal.sel - 1); markSel(); }
  else if (e.key === "Enter" && pal.items[pal.sel]) openBuyer(pal.items[pal.sel].name);
  else if (e.key === "Escape") closePalette();
});
$("#palette").addEventListener("click", (e) => { if (e.target.id === "palette") closePalette(); });
$("#searchBtn").onclick = () => openPalette();
$("#moreCustomers").onclick = () => openPalette();

/* ------------------------------------------------------------------ buyer profile */
const TH_MONTH_FULL = (ym) => { const [y, m] = ym.split("-").map(Number); return `${TH_MONTHS[m - 1]} ${y}`; };
async function openBuyer(name) {
  closePalette();
  state.openDay = null;
  $("#dayKicker").textContent = "ลูกค้า";
  $("#dayTitle").innerHTML = `<span class="who">${avatar(name)}${esc(name)}</span>`;
  $("#dayBody").innerHTML = `<div class="skeleton" style="height:90px"></div><div class="skeleton" style="height:200px;margin-top:14px"></div>`;
  $("#drawer").classList.add("show");
  $("#scrim").classList.add("show");
  try {
    const p = await api(`/api/buyer?name=${encodeURIComponent(name)}`);
    $("#dayKicker").textContent = `ลูกค้า · อันดับ ${p.rank} จาก ${int(p.customers)} คน (ตามยอดซื้อ)`;
    $("#dayTitle").innerHTML = `<span class="who">${avatar(p.name)}${esc(p.name)}${tagIcons(p.name)}</span>`;
    const sameDay = p.first.slice(0, 10) === p.last.slice(0, 10);
    const maxMonth = Math.max(...p.months.map((m) => m.gross), 1);
    $("#dayBody").innerHTML = `
      <div class="day-stats">
        <div class="stat"><div class="l">ซื้อทั้งหมด</div><div class="v">${int(p.orders)} ครั้ง</div><div class="s">${p.canceled ? `ยกเลิก ${p.canceled}` : "ไม่มียกเลิก"}</div></div>
        <div class="stat"><div class="l">ยอดซื้อรวม</div><div class="v">${money(p.spent)}</div><div class="s">ไม่นับที่ยกเลิก</div></div>
        <div class="stat"><div class="l">ต่อออเดอร์</div><div class="v">${money(p.avg)}</div><div class="s">เฉลี่ย</div></div>
        <div class="stat"><div class="l">เป็นลูกค้า</div><div class="v">${int(p.days_as_customer)} วัน</div><div class="s">${sameDay ? dayShort(p.first.slice(0, 10)) : `${dayShort(p.first.slice(0, 10))} – ${dayShort(p.last.slice(0, 10))}`}</div></div>
      </div>
      <div class="flags">
        ${p.disputes ? `<span class="tag-bad">ข้อพิพาท ${p.disputes} ครั้ง</span>` : `<span class="tag-good">ไม่เคยมีข้อพิพาท</span>`}
        ${p.reviews_pos ? `<span class="tag-good">รีวิวบวก ${p.reviews_pos}</span>` : ""}
        ${p.reviews_neg ? `<span class="tag-bad">รีวิวลบ ${p.reviews_neg}</span>` : ""}
        ${p.orders >= 5 ? `<span class="tag-regular">ลูกค้าประจำ</span>` : p.orders === 1 ? `<span class="tag-plain">ซื้อครั้งแรก</span>` : ""}
        <span class="tag-plain">ซื้อล่าสุด ${dayShort(p.last.slice(0, 10))} ${hhmm(p.last)}</span>
      </div>
      <div class="section-title">โน้ต / แท็ก</div>
      ${notesEditor(p.name)}
      <div class="section-title">ซื้ออะไรบ้าง</div>
      <div id="buyerOffers" class="offers"></div>
      ${p.months.length > 1 ? `<div class="section-title">ซื้อรายเดือน</div><div class="weekbars months">${p.months.map((m) => `
        <div class="wk"><span class="lab">${TH_MONTH_FULL(m.month)}</span>
          <div class="track"><div class="fill" style="width:${(m.gross / maxMonth) * 100}%"></div></div>
          <span class="v">${money(m.gross, 0)} · ${m.orders}</span></div>`).join("")}</div>` : ""}
      <div class="section-title">ประวัติการซื้อ (${p.list.length})</div>
      <div class="table-wrap"><table class="orders">${ordersTable(p.list, "created", "เวลาสั่ง", false)}</table></div>`;
    renderOffers($("#buyerOffers"), p.offers);
  } catch (e) {
    $("#dayBody").innerHTML = `<div class="empty">${esc(e.message)}</div>`;
  }
}
document.addEventListener("click", async (e) => {
  const link = e.target.closest("[data-buyer]");
  if (link) { e.preventDefault(); openBuyer(link.dataset.buyer); return; }
  const tagBtn = e.target.closest(".tag-toggle");
  if (tagBtn) { tagBtn.classList.toggle("on"); return; }
  const saveBtn = e.target.closest("[data-save-notes]");
  if (saveBtn) { saveNotes(saveBtn.closest(".notes-box")); return; }
  const openChat = e.target.closest("[data-open-chat]");
  if (openChat) {
    const id = openChat.dataset.openChat;
    try { await api("/api/open-order", { id }); toast("เปิดออเดอร์ในเบราว์เซอร์แล้ว แชทอยู่ในหน้าออเดอร์"); } catch (err) { toast(err.message, true); }
    markChatsRead({ ids: [id] });
    return;
  }
  const readChat = e.target.closest("[data-read-chat]");
  if (readChat) { markChatsRead({ ids: [readChat.dataset.readChat] }); return; }
  const copy = e.target.closest("[data-copy]");
  if (copy) {
    e.preventDefault();
    if (await copyText(copy.dataset.copy)) {
      copy.innerHTML = ICON_OK;
      copy.classList.add("done");
      toast(`คัดลอกเลขออเดอร์แล้ว: ${copy.dataset.copy}`);
      setTimeout(() => { copy.innerHTML = ICON_COPY; copy.classList.remove("done"); }, 1500);
    } else toast("คัดลอกไม่สำเร็จ", true);
    return;
  }
  const open = e.target.closest("[data-open-order]");
  if (open) {
    e.preventDefault();
    try { await api("/api/open-order", { id: open.dataset.openOrder }); toast("เปิดออเดอร์ในเบราว์เซอร์แล้ว"); }
    catch (err) { toast(err.message, true); }
  }
});

function renderBot(bot) {
  const b = $("#botBtn");
  b.classList.toggle("on", !!bot?.running);
  $("#botText").textContent = bot?.running ? "บอททำงานอยู่" : "บอทหยุดอยู่";
  const names = { orders: "แจ้งออเดอร์", report: "สรุปรายวัน", schedule: "เปิด/ปิดร้าน" };
  b.title = bot?.running
    ? "กำลังทำ: " + bot.tasks.map((t) => `${names[t.name] || t.name}${t.ok === false ? " (มีปัญหา)" : ""}`).join(", ") + "\nคลิกเพื่อหยุด"
    : "คลิกเพื่อเริ่มบอทแจ้งเตือนออเดอร์ / สรุปยอดรายวันเข้า Discord";
}

/* ------------------------------------------------------------------ day drawer */
async function openDay(date) {
  state.openDay = date;
  $("#dayTitle").textContent = dayLong(date);
  $("#dayKicker").textContent = "รายละเอียดวัน · นับตามเวลาที่ส่งของ";
  $("#dayBody").innerHTML = `<div class="skeleton" style="height:90px"></div><div class="skeleton" style="height:160px;margin-top:14px"></div>`;
  $("#drawer").classList.add("show");
  $("#scrim").classList.add("show");
  if (state.data) renderDaily($("#dailyChart"), state.data.daily, state.data.range.avg_day, openDay, date);
  try {
    const d = await api(`/api/day?date=${date}`);
    if (state.openDay !== date) return;
    $("#dayBody").innerHTML = `
      <div class="day-stats">
        <div class="stat"><div class="l">ยอดขาย</div><div class="v">${money(d.gross)}</div><div class="s" title="เทียบกับวันก่อน">${delta(d.delta_pct)}</div></div>
        <div class="stat"><div class="l">ออเดอร์</div><div class="v">${int(d.orders)}</div><div class="s">วันก่อน ${int(d.prev_orders)}</div></div>
        <div class="stat"><div class="l">Net ≈</div><div class="v">${d.net != null ? money(d.net) : "—"}</div><div class="s">หลังหักค่าธรรมเนียม</div></div>
        <div class="stat"><div class="l">ต่อออเดอร์</div><div class="v">${money(d.avg_ticket)}</div><div class="s">${d.disputed ? `ข้อพิพาท ${d.disputed}` : d.canceled ? `ยกเลิก ${d.canceled}` : "ไม่มีปัญหา"}</div></div>
      </div>
      <div class="section-title">ยอดตามช่วงเวลา</div>
      <div id="dayHours" class="chart chart-sm"></div>
      <div class="section-title">แยกตามสินค้า</div>
      <div id="dayOffers" class="offers"></div>
      <div class="section-title" style="display:flex;justify-content:space-between;align-items:center">ออเดอร์ทั้งหมด (${d.list.length})
        <button class="btn sm" id="sendDay">ส่งสรุปวันนี้เข้า Discord</button></div>
      <div class="table-wrap"><table class="orders">${ordersTable(d.list, "delivered", "เวลาส่ง")}</table></div>`;
    renderHours($("#dayHours"), d.hours);
    renderOffers($("#dayOffers"), d.offers);
    $("#sendDay").onclick = async (e) => {
      e.target.disabled = true;
      try { await api("/api/send-day", { date }); toast("ส่งสรุปเข้า Discord แล้ว"); }
      catch (err) { toast(err.message, true); }
      finally { e.target.disabled = false; }
    };
  } catch (e) {
    $("#dayBody").innerHTML = `<div class="empty">โหลดไม่สำเร็จ: ${esc(e.message)}</div>`;
  }
}
function closeDay() {
  state.openDay = null;
  $("#drawer").classList.remove("show");
  $("#scrim").classList.remove("show");
  if (state.data) renderDaily($("#dailyChart"), state.data.daily, state.data.range.avg_day, openDay, null);
}

/* ------------------------------------------------------------------ sync */
function setSync(kind, text) {
  const el = $("#syncStatus");
  el.className = "sync-status " + (kind === "busy" ? "busy" : kind === "err" ? "err" : "");
  $("#syncText").textContent = text;
}
async function loadDashboard() {
  const d = await api(`/api/dashboard?days=${state.days}`);
  if (d.needs_setup) { openSettings(true); return false; }
  state.data = d;
  render();
  return true;
}
async function syncAndLoad({ showLoader = false } = {}) {
  if (state.syncing) return;
  state.syncing = true;
  $("#refreshBtn").classList.add("spin");
  setSync("busy", "กำลังอัปเดต…");
  if (showLoader) $("#loader").classList.add("show");
  try {
    let s = await api("/api/sync", { days: state.days });
    while (s.running) {
      await sleep(600);
      s = await api("/api/sync");
      const txt = `โหลดออเดอร์แล้ว ${s.pages} หน้า` + (s.oldest ? ` · ย้อนถึง ${dayShort(s.oldest.slice(0, 10))}` : "");
      $("#loaderText").textContent = txt;
      setSync("busy", txt);
    }
    if (s.error) throw new Error(s.error);
    await loadDashboard();
    loadStock();
    const now = new Date();
    setSync("ok", `อัปเดตล่าสุด ${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`);
  } catch (e) {
    setSync("err", "อัปเดตไม่สำเร็จ");
    if (/failed to fetch/i.test(e.message)) beat();   // the app itself is unreachable: let the connection check handle it
    else toast(e.message, true);
  } finally {
    state.syncing = false;
    $("#refreshBtn").classList.remove("spin");
    $("#loader").classList.remove("show");
  }
}

/* ------------------------------------------------------------------ settings */
async function openSettings(firstTime = false) {
  const f = $("#settingsForm");
  $("#setupNote").hidden = !firstTime;
  $("#settingsMsg").textContent = "";
  try {
    const s = await api("/api/settings");
    f.client_id.value = s.client_id || "";
    f.client_secret.value = "";
    f.client_secret.placeholder = s.has_secret ? "ตั้งไว้แล้ว · เว้นว่าง = ไม่เปลี่ยน" : "วาง Client Secret";
    f.webhook.value = "";
    f.webhook.placeholder = s.has_webhook ? "ตั้งไว้แล้ว · เว้นว่าง = ไม่เปลี่ยน" : "https://discord.com/api/webhooks/…";
    f.mention.value = s.mention || "";
    f.orders_enabled.checked = s.orders_enabled;
    f.report_enabled.checked = s.report_enabled;
    f.report_time.value = s.report_time;
    f.schedule_enabled.checked = s.schedule_enabled;
    f.schedule_windows.value = s.schedule_windows;
    f.chats_enabled.checked = s.chats_enabled;
    f.stock_enabled.checked = s.stock_enabled;
    f.stock_min_qty.value = s.stock_min_qty;
    f.stock_min_days.value = s.stock_min_days;
  } catch (e) { toast(e.message, true); }
  $("#settings").classList.add("show");
}
async function saveSettings() {
  const f = $("#settingsForm");
  return api("/api/settings", {
    client_id: f.client_id.value.trim(), client_secret: f.client_secret.value.trim(),
    webhook: f.webhook.value.trim(), mention: f.mention.value.trim(),
    orders_enabled: f.orders_enabled.checked, report_enabled: f.report_enabled.checked,
    report_time: f.report_time.value.trim(), schedule_enabled: f.schedule_enabled.checked,
    schedule_windows: f.schedule_windows.value.trim(), chats_enabled: f.chats_enabled.checked,
    stock_enabled: f.stock_enabled.checked, stock_min_qty: Number(f.stock_min_qty.value) || 0,
    stock_min_days: Number(f.stock_min_days.value) || 0,
  });
}
$("#settingsForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  try {
    const firstTime = !$("#setupNote").hidden;
    await saveSettings();
    $("#settings").classList.remove("show");
    toast("บันทึกการตั้งค่าแล้ว");
    if (firstTime || !state.data) syncAndLoad({ showLoader: true });
    else loadDashboard().catch(() => {});
  } catch (err) { $("#settingsMsg").textContent = err.message; }
});
$("#testConn").onclick = async () => {
  try { await saveSettings(); await api("/api/test-connection", {}); $("#settingsMsg").textContent = "เชื่อมต่อ Eldorado ได้ ✓"; }
  catch (e) { $("#settingsMsg").textContent = "เชื่อมต่อไม่ได้: " + e.message; }
};
$("#testDiscord").onclick = async () => {
  try { await saveSettings(); await api("/api/test-discord", {}); $("#settingsMsg").textContent = "ส่งข้อความทดสอบแล้ว ✓ เช็กใน Discord"; }
  catch (e) { $("#settingsMsg").textContent = e.message; }
};
document.querySelectorAll("[data-close]").forEach((b) => (b.onclick = () => $("#settings").classList.remove("show")));

/* ------------------------------------------------------------------ connection to the local app */
const conn = { fails: 0, offline: false };
async function beat() {
  try {
    await api("/api/heartbeat", {});
    conn.fails = 0;
    if (conn.offline) {
      conn.offline = false;
      $("#offline").classList.remove("show");
      toast("เชื่อมต่อกลับมาแล้ว");
      syncAndLoad();
    }
  } catch {
    conn.fails += 1;
    if (conn.fails >= 2 && !conn.offline) {
      conn.offline = true;
      $("#offline").classList.add("show");
    }
    if (conn.offline) setTimeout(beat, 5000);  // keep trying while the overlay is up
  }
}
$("#retryConn").onclick = () => beat();

/* ------------------------------------------------------------------ updates */
const upd = { info: null, polling: false };
async function checkUpdate(force = false) {
  try {
    const u = await api(`/api/update${force ? "?force=1" : ""}`);
    upd.info = u;
    $("#verText").textContent = `v${u.current}`;
    $("#footVer").textContent = `Eldorado Sales v${u.current}`;
    $("#updateBtn").hidden = !u.available;
    if (u.available) $("#updateText").textContent = `อัปเดต v${u.latest}`;
    return u;
  } catch (e) {
    return { error: e.message };
  }
}
function openUpdate() {
  const u = upd.info;
  if (!u?.available) return;
  $("#updFrom").textContent = `v${u.current}`;
  $("#updTo").textContent = `v${u.latest}`;
  $("#updDate").textContent = u.date ? `ออกเมื่อ ${u.date}` : "";
  $("#updNotes").textContent = u.notes || "ปรับปรุงทั่วไป";
  $("#updStatus").textContent = "";
  $("#updGo").disabled = false;
  $("#updateModal").classList.add("show");
}
async function runUpdate() {
  const target = upd.info?.latest;
  $("#updGo").disabled = true;
  document.querySelectorAll("[data-close-update]").forEach((b) => (b.disabled = true));
  try {
    await api("/api/update", {});
  } catch (e) {
    $("#updStatus").textContent = e.message;
    $("#updGo").disabled = false;
    document.querySelectorAll("[data-close-update]").forEach((b) => (b.disabled = false));
    return;
  }
  // follow progress; the server restarts itself into the new version, then this page reloads
  const started = Date.now();
  while (Date.now() - started < 180000) {
    await sleep(700);
    try {
      const v = await api("/api/version");
      if (v.version === target) { $("#updStatus").textContent = "เสร็จแล้ว กำลังโหลดใหม่…"; location.reload(); return; }
      if (v.update.error) {
        $("#updStatus").textContent = "อัปเดตไม่สำเร็จ: " + v.update.error;
        $("#updGo").disabled = false;
        document.querySelectorAll("[data-close-update]").forEach((b) => (b.disabled = false));
        return;
      }
      $("#updStatus").textContent = v.update.step || "กำลังอัปเดต…";
    } catch {
      $("#updStatus").textContent = "กำลังเปิดแอปใหม่…";   // server is restarting
    }
  }
  $("#updStatus").textContent = "ใช้เวลานานผิดปกติ ลองปิดแล้วเปิดแอปใหม่";
}
$("#updateBtn").onclick = openUpdate;
$("#updGo").onclick = runUpdate;
document.querySelectorAll("[data-close-update]").forEach((b) => (b.onclick = () => $("#updateModal").classList.remove("show")));
$("#checkUpdate").onclick = async () => {
  $("#verMsg").textContent = "กำลังตรวจ…";
  const u = await checkUpdate(true);
  if (u.available) { $("#verMsg").textContent = `มีเวอร์ชันใหม่ v${u.latest}`; $("#settings").classList.remove("show"); openUpdate(); }
  else if (u.dev) $("#verMsg").textContent = "นี่คือโฟลเดอร์ต้นฉบับ (ปล่อยอัปเดตด้วย publish_update.cmd ไม่อัปเดตตัวเอง)";
  else $("#verMsg").textContent = u.error ? "ตรวจไม่ได้ตอนนี้ (ออฟไลน์หรือยังไม่มีเวอร์ชันที่เผยแพร่)" : "เป็นเวอร์ชันล่าสุดแล้ว ✓";
};

/* ------------------------------------------------------------------ themes */
const THEMES = { dark: { name: "ดำ", bar: "#0a0c11" }, light: { name: "ขาว", bar: "#ffffff" }, pink: { name: "ชมพู", bar: "#fff0f6" } };
function applyTheme(name, announce = false) {
  if (!THEMES[name]) name = "dark";
  document.documentElement.dataset.theme = name;
  store.set("theme", name);
  $('meta[name="theme-color"]').setAttribute("content", THEMES[name].bar);   // app window title bar
  document.querySelectorAll("#themeSwitch button").forEach((b) => b.classList.toggle("on", b.dataset.theme === name));
  if (announce) toast(`เปลี่ยนเป็นธีม${THEMES[name].name}แล้ว`);
}
document.querySelectorAll("#themeSwitch button").forEach((b) => b.addEventListener("click", () => applyTheme(b.dataset.theme, true)));
applyTheme(document.documentElement.dataset.theme);

/* ------------------------------------------------------------------ wiring */
function markRange() {
  document.querySelectorAll("#range button").forEach((b) => b.classList.toggle("on", +b.dataset.days === state.days));
}
document.querySelectorAll("#range button").forEach((b) => b.addEventListener("click", async () => {
  state.days = +b.dataset.days;
  store.set("days", state.days);
  markRange();
  try { await loadDashboard(); } catch (e) { toast(e.message, true); }
  syncAndLoad();   // a longer range may need older orders
}));
$("#refreshBtn").onclick = () => syncAndLoad();
$("#settingsBtn").onclick = () => openSettings(false);
$("#drawerClose").onclick = closeDay;
$("#scrim").onclick = closeDay;
document.addEventListener("keydown", (e) => {
  const typing = /^(INPUT|TEXTAREA)$/.test(document.activeElement?.tagName || "");
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") { e.preventDefault(); openPalette(); return; }
  if (e.key === "/" && !typing) { e.preventDefault(); openPalette(); return; }
  if (e.key === "Escape") {
    if ($("#palette").classList.contains("show")) closePalette();
    else { closeDay(); $("#settings").classList.remove("show"); }
  }
});
$("#botBtn").onclick = async () => {
  const running = $("#botBtn").classList.contains("on");
  try {
    const bot = await api("/api/bot", { action: running ? "stop" : "start" });
    renderBot(bot);
    toast(running ? "หยุดบอทแล้ว" : "เริ่มบอทแล้ว - แจ้งเตือนเข้า Discord ตามที่ตั้งไว้");
    setTimeout(() => api("/api/bot").then(renderBot).catch(() => {}), running ? 1500 : 4000);
  } catch (e) { toast(e.message, true); }
};
let resizeTimer;
addEventListener("resize", () => { clearTimeout(resizeTimer); resizeTimer = setTimeout(render, 120); });

(async function init() {
  if (![7, 14, 30, 60, 90].includes(state.days)) state.days = 30;
  markRange();
  await loadNotes();
  let ok = false;
  try { ok = await loadDashboard(); } catch (e) { toast(e.message, true); }
  if (ok) loadStock();
  const empty = !state.data || !state.data.cached;
  if (ok || state.data) syncAndLoad({ showLoader: empty });
  // deep links: #day=YYYY-MM-DD opens that day, #settings opens settings
  const m = location.hash.match(/^#day=(\d{4}-\d{2}-\d{2})$/);
  const b = location.hash.match(/^#buyer=(.+)$/);
  const sq = location.hash.match(/^#search=(.*)$/);
  if (m) openDay(m[1]);
  else if (b) openBuyer(decodeURIComponent(b[1]));
  else if (sq) openPalette(decodeURIComponent(sq[1]));
  else if (location.hash === "#settings") openSettings(false);
  setInterval(() => syncAndLoad(), 120000);   // keep numbers fresh every 2 minutes
  beat();
  setInterval(beat, 15000);
  document.addEventListener("visibilitychange", () => {
    // Edge pauses minimised windows; catch up as soon as the window is visible again
    if (!document.hidden) { beat(); syncAndLoad(); }
  });
  checkUpdate().then((u) => { if (location.hash === "#update" && u.available) openUpdate(); });
  setInterval(() => checkUpdate(), 30 * 60 * 1000);   // server caches the real check for 6 hours
})();
