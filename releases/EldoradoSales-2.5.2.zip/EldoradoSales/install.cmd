@echo off
setlocal EnableExtensions
title Eldorado Sales - Install
cd /d "%~dp0"
set "APPDIR=%CD%"

echo.
echo  ==================================================
echo    Eldorado Sales - installer
echo  ==================================================
echo.

set "NOSHORTCUT="
set "NOLAUNCH="
for %%A in (%*) do (
  if /i "%%~A"=="--no-shortcut" set "NOSHORTCUT=1"
  if /i "%%~A"=="--no-launch" set "NOLAUNCH=1"
)

rem ---------------------------------------------------------------- 1. Python
echo  [1/5] Looking for Python 3.10 or newer...
set "PY="
py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>&1 && set "PY=py -3"
if not defined PY python -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>&1 && set "PY=python"
if not defined PY if exist "%LocalAppData%\Programs\Python\Python312\python.exe" set PY="%LocalAppData%\Programs\Python\Python312\python.exe"
if not defined PY (
  echo        Python not found - installing Python 3.12 with winget...
  winget install -e --id Python.Python.3.12 --scope user --silent --accept-package-agreements --accept-source-agreements
  if exist "%LocalAppData%\Programs\Python\Python312\python.exe" set PY="%LocalAppData%\Programs\Python\Python312\python.exe"
)
if not defined PY (
  echo.
  echo  ERROR: could not install Python automatically.
  echo  Please install it from https://www.python.org/downloads/
  echo  ^(tick "Add python.exe to PATH"^), then run install.cmd again.
  goto :fail
)
%PY% --version

rem ---------------------------------------------------------------- 2. venv + packages
echo  [2/5] Creating the app's own Python environment (.venv)...
if not exist ".venv\Scripts\python.exe" (
  %PY% -m venv .venv || goto :fail
)
echo  [3/5] Installing packages (requests, tzdata)...
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -q --upgrade pip
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -q -r requirements.txt || goto :fail
".venv\Scripts\python.exe" -c "import requests, tzdata, eldobot.webapp" || goto :fail

rem ---------------------------------------------------------------- 3. settings files
echo  [4/5] Preparing settings...
if not exist "data" mkdir "data"
if not exist ".env" copy /y ".env.example" ".env" >nul
if not exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" if not exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
  echo        NOTE: Microsoft Edge not found - the app will open in your normal browser instead.
)

rem ---------------------------------------------------------------- 4. desktop shortcut
if defined NOSHORTCUT goto :skipshortcut
echo  [5/5] Creating desktop shortcut "Eldorado Sales"...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$d=$env:APPDIR; $q=[char]34; $s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\Eldorado Sales.lnk'); $s.TargetPath=$d+'\.venv\Scripts\pythonw.exe'; $s.Arguments=$q+$d+'\eldorado_gui.py'+$q; $s.WorkingDirectory=$d; $s.IconLocation=$d+'\ui\icon.ico'; $s.Description='Eldorado Sales dashboard'; $s.Save()" || goto :fail
:skipshortcut

echo.
echo  Done! Open "Eldorado Sales" on your desktop (or double-click "Eldorado Sales.cmd").
echo  First time: the settings window opens - paste your Client ID / Client Secret
echo  from eldorado.gg ^> Dashboard ^> Seller API.
echo.
if not defined NOLAUNCH start "" ".venv\Scripts\pythonw.exe" "%APPDIR%\eldorado_gui.py"
if not defined NOLAUNCH pause
exit /b 0

:fail
echo.
echo  Install failed. Take a screenshot of this window and send it to whoever gave you the app.
pause
exit /b 1
