"""Customers: search buyers by name and show what they bought from the shop.

Works on the slim orders kept by history.OrderHistory. "Spent" leaves out canceled (refunded) orders.
"""
from __future__ import annotations

from collections import defaultdict
from datetime import datetime

from .history import DISPUTE_STATES, NOT_SALES
from .util import parse_dt


def key(name: str | None) -> str:
    return (name or "").strip().lower()


class _Agg:
    __slots__ = ("name", "orders", "spent", "canceled", "disputes", "pos", "neg", "first", "last", "offers")

    def __init__(self, name: str):
        self.name = name
        self.orders = self.canceled = self.disputes = self.pos = self.neg = 0
        self.spent = 0.0
        self.first = self.last = ""
        self.offers: dict[str, list] = defaultdict(lambda: [0, 0.0])

    def add(self, o: dict) -> None:
        self.orders += 1
        created = o["created"]
        self.first = created if not self.first or created < self.first else self.first
        self.last = created if created > self.last else self.last
        if o.get("state") in NOT_SALES:
            self.canceled += 1
        else:
            self.spent += o["total"]
            row = self.offers[o["title"]]
            row[0] += 1
            row[1] += o["total"]
        if o.get("state") in DISPUTE_STATES or o.get("dispute"):
            self.disputes += 1
        if o.get("review") == "Positive":
            self.pos += 1
        elif o.get("review") == "Negative":
            self.neg += 1

    def summary(self, tz) -> dict:
        return {
            "name": self.name, "orders": self.orders, "spent": round(self.spent, 2), "canceled": self.canceled,
            "disputes": self.disputes, "reviews_pos": self.pos, "reviews_neg": self.neg,
            "first": parse_dt(self.first).astimezone(tz).isoformat() if self.first else None,
            "last": parse_dt(self.last).astimezone(tz).isoformat() if self.last else None,
        }


def _index(orders) -> dict[str, _Agg]:
    idx: dict[str, _Agg] = {}
    for o in orders:
        k = key(o.get("buyer"))
        if not k:
            continue
        agg = idx.get(k)
        if agg is None:
            agg = idx[k] = _Agg(o["buyer"].strip())
        agg.add(o)
    return idx


def search(orders: dict, q: str, tz, limit: int = 25) -> dict:
    """Buyers whose name contains q (case-insensitive). Empty q = best customers."""
    idx = _index(orders.values())
    q = key(q)
    hits = [a for k, a in idx.items() if q in k] if q else list(idx.values())

    def rank(a: _Agg):
        k = key(a.name)
        return (0 if k == q else 1 if k.startswith(q) else 2) if q else 0, -a.orders, -a.spent

    hits.sort(key=rank)
    return {"query": q, "total": len(hits), "buyers_known": len(idx),
            "results": [a.summary(tz) for a in hits[:limit]]}


def profile(orders: dict, name: str, tz) -> dict | None:
    """Everything one buyer did with the shop."""
    k = key(name)
    mine = [o for o in orders.values() if key(o.get("buyer")) == k]
    if not mine:
        return None
    agg = _Agg(mine[0]["buyer"].strip())
    for o in mine:
        agg.add(o)

    # rank among all customers by money spent
    idx = _index(orders.values())
    by_spend = sorted(idx.values(), key=lambda a: -a.spent)
    rank = next((i + 1 for i, a in enumerate(by_spend) if key(a.name) == k), None)

    months: dict[str, list] = defaultdict(lambda: [0, 0.0])
    for o in mine:
        if o.get("state") in NOT_SALES:
            continue
        m = parse_dt(o["created"]).astimezone(tz).strftime("%Y-%m")
        months[m][0] += 1
        months[m][1] += o["total"]

    mine.sort(key=lambda o: o["created"], reverse=True)
    total = agg.spent or 1.0
    out = agg.summary(tz)
    out.update({
        "rank": rank, "customers": len(idx),
        "avg": round(agg.spent / max(1, agg.orders - agg.canceled), 2),
        "days_as_customer": (parse_dt(agg.last).date() - parse_dt(agg.first).date()).days + 1,
        "offers": [{"title": t, "orders": n, "gross": round(g, 2), "share": round(g / total * 100, 1)}
                   for t, (n, g) in sorted(agg.offers.items(), key=lambda kv: -kv[1][1])],
        "months": [{"month": m, "orders": n, "gross": round(g, 2)} for m, (n, g) in sorted(months.items())],
        "list": [_row(o, tz) for o in mine],
    })
    return out


def _row(o: dict, tz) -> dict:
    created = parse_dt(o["created"]).astimezone(tz)
    delivered = parse_dt(o["delivered"]).astimezone(tz) if o.get("delivered") else None
    return {"id": o.get("id"), "created": created.isoformat(), "delivered": delivered.isoformat() if delivered else None,
            "title": o["title"], "total": o["total"], "qty": o.get("qty", 1), "state": o.get("state"),
            "buyer": o.get("buyer", ""), "dispute": o.get("dispute", ""), "review": o.get("review")}


def range_customers(orders: dict, range_rows: list, tz, top: int = 10) -> dict:
    """Who bought in the selected range, and how many of those orders came from returning customers."""
    first_seen: dict[str, datetime] = {}
    lifetime: dict[str, int] = defaultdict(int)
    for o in orders.values():
        k = key(o.get("buyer"))
        if not k or o.get("state") in NOT_SALES:
            continue
        c = parse_dt(o["created"])
        if k not in first_seen or c < first_seen[k]:
            first_seen[k] = c
        lifetime[k] += 1

    per: dict[str, dict] = {}
    returning = named = 0
    for t, o in range_rows:
        k = key(o.get("buyer"))
        if not k:
            continue
        named += 1
        p = per.setdefault(k, {"name": o["buyer"].strip(), "orders": 0, "gross": 0.0, "last": t})
        p["orders"] += 1
        p["gross"] += o["total"]
        p["last"] = max(p["last"], t)
        if first_seen.get(k) and first_seen[k] < parse_dt(o["created"]):
            returning += 1
    best = sorted(per.items(), key=lambda kv: (-kv[1]["orders"], -kv[1]["gross"]))[:top]
    return {
        "unique": len(per),
        "repeat_buyers": sum(1 for p in per.values() if p["orders"] >= 2),
        "returning_share": round(returning / named * 100, 1) if named else None,
        "named_orders": named,
        "top": [{"name": p["name"], "orders": p["orders"], "gross": round(p["gross"], 2),
                 "lifetime": lifetime.get(k, p["orders"]), "last": p["last"].isoformat()} for k, p in best],
    }
