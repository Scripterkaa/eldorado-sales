"""Stock: how many of each offer are left, how fast they sell, and how many days that lasts.

Read-only (offers list + the local order cache). Alerts go to Discord once per low-stock episode.
"""
from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timedelta, timezone

from .history import NOT_SALES
from .util import JsonStore, log, parse_dt

RATE_DAYS = 7


def offer_rows(offers, orders, tz, now: datetime | None = None, rate_days: int = RATE_DAYS) -> list[dict]:
    """One row per offer: stock, sold per day (last `rate_days` days), sold today, days left."""
    now = now or datetime.now(timezone.utc)
    since = now - timedelta(days=rate_days)
    today = now.astimezone(tz).date()
    sold = defaultdict(int)
    sold_today = defaultdict(int)
    for o in orders:
        if not o.get("delivered") or o.get("state") in NOT_SALES or not o.get("offer"):
            continue
        t = parse_dt(o["delivered"])
        oid = str(o["offer"]).lower()
        if t >= since:
            sold[oid] += int(o.get("qty") or 1)
        if t.astimezone(tz).date() == today:
            sold_today[oid] += int(o.get("qty") or 1)

    rows = []
    for kind, of in offers:
        oid = str(of.get("id", "")).lower()
        stock = int(of.get("quantity") or 0)
        per_day = sold[oid] / rate_days
        rows.append({
            "id": of.get("id"), "kind": kind, "title": (of.get("offerTitle") or "").strip(),
            "state": of.get("offerState"), "stock": stock,
            "price": float((of.get("pricePerUnitInUSD") or of.get("pricePerUnit") or {}).get("amount") or 0),
            "sold_period": sold[oid], "per_day": round(per_day, 1), "today": sold_today[oid],
            "days_left": round(stock / per_day, 1) if per_day > 0 else None,
        })
    rows.sort(key=lambda r: (r["state"] != "Active", r["days_left"] if r["days_left"] is not None else 1e9, -r["per_day"]))
    return rows


def is_low(row: dict, min_qty: int, min_days: float) -> bool:
    if row["state"] != "Active":
        return False
    return row["stock"] <= min_qty or (row["days_left"] is not None and row["days_left"] < min_days)


class StockWatcher:
    """Bot task: post a Discord alert when an active offer runs low (again after a restock)."""

    def __init__(self, api, notifier, store: JsonStore, cfg: dict, tz, history, own_history: bool = False):
        self.api = api
        self.notify = notifier
        self.store = store
        self.tz = tz
        self.history = history
        self.own_history = own_history
        self.min_qty = int(cfg.get("min_qty", 10))
        self.min_days = float(cfg.get("min_days", 2))

    def check(self) -> list[dict]:
        if self.own_history:  # running without the app window: keep the recent sales fresh ourselves
            self.history.sync(RATE_DAYS + 1)
        rows = offer_rows(self.api.all_my_offers(), list(self.history.orders.values()), self.tz)
        alerted = self.store.data.setdefault("stock_alerted", {})
        lows = []
        for r in rows:
            oid = str(r["id"]).lower()
            if is_low(r, self.min_qty, self.min_days):
                lows.append(r)
                if oid not in alerted:
                    left = f" (~{r['days_left']} days at {r['per_day']}/day)" if r["days_left"] is not None else ""
                    self.notify.send("stock", f"LOW STOCK: {r['title']} - {r['stock']} left{left}", alert=True)
                    alerted[oid] = r["stock"]
            elif oid in alerted:
                log("stock", f"restocked: {r['title']} ({r['stock']})")
                del alerted[oid]
        self.store.save()
        return lows
