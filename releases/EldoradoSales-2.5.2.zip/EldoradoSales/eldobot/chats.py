"""New buyer chats, detected from orders.

Eldorado's Seller API has no chat endpoint. What it does have: when a buyer opens a conversation
about an order, the order gets `conversationDetails` (reason, first message, time). We use that.
The API cannot tell whether you already read it on eldorado.gg, so "read" is tracked here:
a chat stays unread until you open it from the app or tick it (data/chat_read.json).
Later replies inside an existing chat are not visible through the API.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path

from .util import JsonStore, parse_dt

REASONS_TH = {
    "Account_Details_Incorrect": "ข้อมูลไอดีไม่ถูกต้อง",
    "Locked_Out_Of_Account": "เข้าไอดีไม่ได้ / โดนล็อก",
    "Order_Not_As_Described": "ไม่ตรงกับที่ลงขาย",
    "Order_Missing_Details": "ข้อมูลไม่ครบ",
    "Gift_Card_Region_Incorrect": "ภูมิภาคกิฟต์การ์ดผิด",
    "Gift_Card_Code_Invalid": "โค้ดใช้ไม่ได้",
    "Admin_Request": "แอดมินติดต่อ",
    "Other": "อื่นๆ",
}
WINDOW_DAYS = 7          # chats older than this are not listed
FIRST_RUN_GRACE = 24     # hours: on first use, older chats start as read so the list isn't flooded


class ChatState:
    def __init__(self, path: Path, now: datetime | None = None):
        self.store = JsonStore(path)
        self._defaults(now)

    def _defaults(self, now: datetime | None = None) -> None:
        self.store.data.setdefault("read", {})
        if "since" not in self.store.data:  # when chat tracking started on this computer
            self.store.data["since"] = (now or datetime.now(timezone.utc)).isoformat()
            self.store.save()

    @property
    def read(self) -> dict:
        return self.store.data["read"]

    @property
    def baseline(self) -> datetime:
        """Chats older than this count as read: we can't know what was read before tracking began."""
        return parse_dt(self.store.data["since"]) - timedelta(hours=FIRST_RUN_GRACE)

    def reload(self) -> None:
        self.store.data = JsonStore(self.store.path).data or {}
        self._defaults()

    def is_unread(self, o: dict) -> bool:
        c = o.get("chat")
        if not c:
            return False
        at = parse_dt(c["at"])
        if at < self.baseline:
            return False
        seen = self.read.get(o["id"])
        return not seen or at > parse_dt(seen)  # a newer conversation reopens it

    def mark(self, orders_by_id: dict, ids: list[str]) -> int:
        n = 0
        for oid in ids:
            o = orders_by_id.get(oid)
            if o and o.get("chat"):
                self.read[oid] = o["chat"]["at"]
                n += 1
        self.store.save()
        return n


def unread_chats(orders: dict, state: ChatState, tz, now: datetime | None = None) -> list[dict]:
    now = now or datetime.now(timezone.utc)
    since = now - timedelta(days=WINDOW_DAYS)
    rows = []
    for o in orders.values():
        c = o.get("chat")
        if not c or parse_dt(c["at"]) < since or not state.is_unread(o):
            continue
        rows.append({
            "id": o["id"], "buyer": o.get("buyer", ""), "title": o["title"], "total": o["total"],
            "state": o.get("state"), "reason": c["reason"], "reason_th": REASONS_TH.get(c["reason"], c["reason"]),
            "message": c.get("message", ""), "at": parse_dt(c["at"]).astimezone(tz).isoformat(),
            "created": parse_dt(o["created"]).astimezone(tz).isoformat(),
        })
    rows.sort(key=lambda r: r["at"], reverse=True)
    return rows


class ChatWatcher:
    """Bot task: Discord alert for every new chat (once)."""

    def __init__(self, notifier, store: JsonStore, history, own_history: bool = False):
        self.notify = notifier
        self.store = store
        self.history = history
        self.own_history = own_history

    def check(self) -> int:
        if self.own_history:
            self.history.sync(WINDOW_DAYS, refresh_days=3)
        alerted = self.store.data.setdefault("chat_alerted", {})
        first = not self.store.data.get("chats_initialized")
        since = datetime.now(timezone.utc) - timedelta(days=WINDOW_DAYS)
        new = 0
        for o in list(self.history.orders.values()):
            c = o.get("chat")
            if not c or parse_dt(c["at"]) < since or alerted.get(o["id"]) == c["at"]:
                continue
            alerted[o["id"]] = c["at"]
            if first:
                continue
            new += 1
            reason = REASONS_TH.get(c["reason"], c["reason"])
            msg = (c.get("message") or "").replace("\n", " ")[:300]
            self.notify.send("chat", f"NEW CHAT [{c['reason'].replace('_', ' ')} / {reason}] "
                                     f"buyer {o.get('buyer', '?')} order {o['id'][:8]} :: {msg}", alert=True)
        self.store.data["chats_initialized"] = True
        for oid in [k for k, v in alerted.items() if parse_dt(v) < since]:
            del alerted[oid]
        self.store.save()
        return new
