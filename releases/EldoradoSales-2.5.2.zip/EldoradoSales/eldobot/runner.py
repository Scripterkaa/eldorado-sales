"""Main loop: runs every enabled feature on its own interval in one process. Never touches prices."""
from __future__ import annotations

import threading
import time
from datetime import datetime, timedelta

from .chats import ChatWatcher
from .config import ROOT
from .history import OrderHistory
from .notes import BuyerNotes
from .orders import OrderWatcher
from .report import build_report
from .schedule import ShopSchedule
from .stock import StockWatcher
from .util import JsonStore, log

TICK = 5               # seconds between checks
ERROR_COOLDOWN = 1800  # repeat the same task's error on Discord at most every 30 min


class Runner:
    def __init__(self, api, notifier, cfg: dict, store: JsonStore, history=None, notes=None):
        self.api = api
        self.notify = notifier
        self.cfg = cfg
        self.store = store
        self.tz = cfg["_tz"]
        self.tasks = []  # (name, interval_seconds, fn)
        self.next_run: dict[str, float] = {}
        self.last_error: dict[str, float] = {}
        self.status: dict[str, dict] = {}  # name -> {"last": datetime, "ok": bool, "msg": str}
        self.stop_event = threading.Event()
        self._sched = None

        if notes is None:
            notes = BuyerNotes(ROOT / "data" / "buyer_notes.json")
        if cfg["orders"]["enabled"]:
            watcher = OrderWatcher(api, notifier, store, cfg["orders"], notes=notes)
            self.tasks.append(("orders", max(20, int(cfg["orders"]["interval_seconds"])), watcher.poll))
        own = history is None  # CLI mode: no app window keeping the order cache fresh
        if own and (cfg["stock"]["enabled"] or cfg["chats"]["enabled"]):
            history = OrderHistory(api, ROOT / "data" / "orders_cache.json")
        if cfg["stock"]["enabled"]:
            stock = StockWatcher(api, notifier, store, cfg["stock"], self.tz, history, own_history=own)
            self.tasks.append(("stock", max(120, int(float(cfg["stock"]["interval_minutes"]) * 60)), stock.check))
        if cfg["chats"]["enabled"]:
            chats = ChatWatcher(notifier, store, history, own_history=own and not cfg["stock"]["enabled"])
            self.tasks.append(("chats", 60, chats.check))
        if cfg["schedule"]["enabled"]:
            self._sched = ShopSchedule(api, notifier, store, cfg["schedule"], self.tz)
            self.tasks.append(("schedule", 60, self._sched.tick))
        if cfg["report"]["enabled"]:
            self.tasks.append(("report", 60, self._daily_report_if_due))

    def _daily_report_if_due(self) -> None:
        now = datetime.now(self.tz)
        h, m = (int(x) for x in self.cfg["report"]["time"].split(":"))
        if (now.hour, now.minute) < (h, m):
            return
        day = (now - timedelta(days=1)).date()
        if self.store.data.get("last_report_day") == day.isoformat():
            return
        text = build_report(self.api, day, self.tz, int(self.cfg["report"].get("top_offers", 8)))
        self.notify.send("report", text)
        self.store.data["last_report_day"] = day.isoformat()
        self.store.save()

    def stop(self) -> None:
        self.stop_event.set()

    def run_forever(self) -> None:
        if not self.tasks:
            log("main", "nothing enabled in config.json")
            return
        log("main", "running: " + ", ".join(f"{n} every {i}s" for n, i, _ in self.tasks))
        if self._sched:
            self._safe("schedule", lambda: self._sched.tick(force=True))  # sync real shop state at start
        while not self.stop_event.is_set():
            now = time.monotonic()
            for name, interval, fn in self.tasks:
                if self.stop_event.is_set():
                    break
                if now >= self.next_run.get(name, 0):
                    self.next_run[name] = now + interval
                    self._safe(name, fn)
            self.stop_event.wait(TICK)
        log("main", "bot stopped")

    def _safe(self, name: str, fn) -> None:
        try:
            fn()
            self.status[name] = {"last": datetime.now(), "ok": True, "msg": ""}
        except KeyboardInterrupt:
            raise
        except Exception as exc:
            msg = f"{name} failed: {type(exc).__name__}: {exc}"
            self.status[name] = {"last": datetime.now(), "ok": False, "msg": msg}
            if time.monotonic() - self.last_error.get(name, -ERROR_COOLDOWN) >= ERROR_COOLDOWN:
                self.last_error[name] = time.monotonic()
                self.notify.send("error", msg, alert=True)
            else:
                log("error", msg)
