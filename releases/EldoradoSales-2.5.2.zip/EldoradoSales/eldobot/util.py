"""Small shared helpers: logging, time parsing, .env and JSON state files."""
from __future__ import annotations

import json
import os
import re
import sys
import tempfile
import threading
from datetime import datetime, timezone
from pathlib import Path


def ascii_safe(text: object) -> str:
    """Strip non-ASCII (emoji, Thai) so Windows/farm consoles never show '????'."""
    s = str(text).encode("ascii", "ignore").decode("ascii")
    return re.sub(r"\s+", " ", s).strip()


_listeners: list = []


def add_log_listener(callback) -> None:
    """callback(time_str, tag, full_text) - used by the GUI; may be called from any thread."""
    _listeners.append(callback)


def log(tag: str, msg: str) -> None:
    ts = datetime.now().strftime("%H:%M:%S")
    print(f"[{ts}] [{tag}] {ascii_safe(msg)}", flush=True)  # no-op under pythonw
    for cb in list(_listeners):
        try:
            cb(ts, tag, str(msg))
        except Exception:
            pass


_FRACTION = re.compile(r"(\.\d{6})\d+")


def parse_dt(value: str) -> datetime:
    """Parse Eldorado timestamps like 2026-11-10T19:03:26.8422782Z into aware UTC datetimes."""
    s = value.strip().replace("Z", "+00:00")
    s = _FRACTION.sub(r"\1", s)
    dt = datetime.fromisoformat(s)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def iso_utc(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z")


def load_env(path: Path) -> None:
    """Minimal .env loader (KEY=VALUE per line). Real environment variables win."""
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        value = value.strip().strip('"').strip("'")
        os.environ.setdefault(key.strip(), value)


class JsonStore:
    """Tiny JSON file store, written atomically so a crash never corrupts it."""

    def __init__(self, path: Path):
        self.path = path
        self.data: dict = {}
        self._lock = threading.Lock()
        if path.exists():
            try:
                self.data = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                log("state", f"could not read {path.name}, starting fresh")
                self.data = {}

    def save(self) -> None:
        with self._lock:  # bot thread and GUI thread both save
            self.path.parent.mkdir(parents=True, exist_ok=True)
            fd, tmp = tempfile.mkstemp(dir=self.path.parent, prefix=self.path.name, suffix=".tmp")
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump(self.data, fh, ensure_ascii=False, indent=1)
            os.replace(tmp, self.path)


def money(amount: float) -> str:
    if amount != 0 and abs(amount) < 0.1:  # GaG-style items cost fractions of a cent
        return "$" + f"{amount:.5f}".rstrip("0")
    return f"${amount:,.2f}"


def fail(msg: str) -> None:
    log("error", msg)
    sys.exit(1)
