"""Feature 3: switch the shop online/offline by local time windows."""
from __future__ import annotations

from datetime import datetime, time as dtime

from .util import JsonStore, log


def _hm(text: str) -> dtime:
    h, m = text.strip().split(":")
    return dtime(int(h), int(m))


def in_windows(now: dtime, windows: list[list[str]]) -> bool:
    """Windows like [["09:00", "02:00"]]; an end before the start wraps past midnight."""
    for start_s, end_s in windows:
        start, end = _hm(start_s), _hm(end_s)
        if start == end:
            return True  # whole day
        if start < end:
            if start <= now < end:
                return True
        elif now >= start or now < end:
            return True
    return False


class ShopSchedule:
    def __init__(self, api, notifier, store: JsonStore, cfg: dict, tz):
        self.api = api
        self.notify = notifier
        self.store = store
        self.tz = tz
        self.windows = cfg.get("online") or []
        if not self.windows:
            raise ValueError("schedule.online must list at least one [start, end] window")
        for w in self.windows:
            _hm(w[0]), _hm(w[1])  # validate early

    def desired(self, now: datetime | None = None) -> str:
        now = now or datetime.now(self.tz)
        return "online" if in_windows(now.time(), self.windows) else "offline"

    def tick(self, now: datetime | None = None, force: bool = False) -> str | None:
        want = self.desired(now)
        if not force and self.store.data.get("shop_status") == want:
            return None
        if want == "online":
            self.api.switch_online()
        else:
            self.api.switch_offline()
        self.store.data["shop_status"] = want
        self.store.save()
        self.notify.send("schedule", f"Shop switched {want.upper()} (schedule {self.windows})")
        return want


def manual_switch(api, notifier, store: JsonStore, status: str) -> None:
    (api.switch_online if status == "online" else api.switch_offline)()
    store.data["shop_status"] = status
    store.save()
    log("schedule", f"shop switched {status} manually")
