"""In-app updates: check latest.json, download the release zip, verify it, replace the app files.

Safety:
- the zip's SHA-256 must match latest.json, and the zip must contain a version.py with the same version
- entries must stay inside the app folder (no "../" or absolute paths)
- user files are never touched: .env, data/, config.json, .venv/ (plus dev-only folders)
- every overwritten file is backed up to data/update/backup-<old version>/ first
"""
from __future__ import annotations

import hashlib
import io
import re
import shutil
import subprocess
import sys
import time
import zipfile
from pathlib import Path, PurePosixPath

import requests

from .util import log
from .version import APP_VERSION, UPDATE_MANIFEST

TOP = "EldoradoSales"
PROTECTED = {".env", "data", "config.json", ".venv", "dist", "legacy", "tests", "tools", ".git"}
REQUIRED = {"eldorado_gui.py", "eldobot/__init__.py", "eldobot/version.py", "ui/index.html"}
VERSION_RE = re.compile(r'APP_VERSION\s*=\s*"([^"]+)"')


class UpdateError(RuntimeError):
    pass


def parse_version(v: str) -> tuple:
    parts = re.findall(r"\d+", v or "")
    return tuple(int(p) for p in parts[:4]) or (0,)


def is_dev_copy(root: Path) -> bool:
    """The developer's own folder (has the publish tools): it must never overwrite itself from a release."""
    return (root / "tools" / "publish_update.py").exists()


def check(manifest_url: str | None = None, current: str = APP_VERSION) -> dict:
    url = manifest_url or UPDATE_MANIFEST
    if url.startswith("http"):  # GitHub's raw CDN caches ~5 min per variant; a unique query skips it
        url += ("&" if "?" in url else "?") + f"t={int(time.time())}"
    resp = requests.get(url, timeout=15, headers={"Cache-Control": "no-cache"})
    if resp.status_code != 200:
        raise UpdateError(f"update server HTTP {resp.status_code}")
    m = resp.json()
    for k in ("version", "url", "sha256"):
        if not m.get(k):
            raise UpdateError(f"latest.json missing '{k}'")
    return {
        "current": current, "latest": m["version"], "url": m["url"], "sha256": m["sha256"].lower(),
        "notes": m.get("notes", ""), "date": m.get("date", ""), "size": m.get("size"),
        "available": parse_version(m["version"]) > parse_version(current),
    }


def _safe_rel(name: str) -> str | None:
    """'EldoradoSales/eldobot/x.py' -> 'eldobot/x.py'; None for dirs; raises on unsafe paths."""
    p = PurePosixPath(name)
    if p.is_absolute() or ".." in p.parts or ":" in name or "\\" in name:
        raise UpdateError(f"unsafe path in zip: {name}")
    if not p.parts or p.parts[0] != TOP:
        raise UpdateError(f"unexpected entry in zip: {name}")
    rel = PurePosixPath(*p.parts[1:])
    if not rel.parts or name.endswith("/"):
        return None
    return str(rel)


def inspect_zip(data: bytes, expect_version: str) -> dict[str, bytes]:
    """Validate the release zip and return {relative path: content} for the files to install."""
    try:
        z = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile as exc:
        raise UpdateError("downloaded file is not a valid zip") from exc
    files: dict[str, bytes] = {}
    for info in z.infolist():
        rel = _safe_rel(info.filename)
        if rel is None:
            continue
        if rel.split("/")[0] in PROTECTED:
            continue  # never ship over user files
        files[rel] = z.read(info)
    missing = REQUIRED - files.keys()
    if missing:
        raise UpdateError(f"zip is missing {', '.join(sorted(missing))}")
    m = VERSION_RE.search(files["eldobot/version.py"].decode("utf-8", "replace"))
    if not m or m.group(1) != expect_version:
        raise UpdateError(f"zip version {m.group(1) if m else '?'} does not match {expect_version}")
    return files


def download(info: dict, progress=None) -> bytes:
    with requests.get(info["url"], stream=True, timeout=60) as resp:
        if resp.status_code != 200:
            raise UpdateError(f"download HTTP {resp.status_code}")
        total = int(resp.headers.get("Content-Length") or 0)
        buf = io.BytesIO()
        for chunk in resp.iter_content(64 * 1024):
            buf.write(chunk)
            if progress:
                progress(buf.tell(), total)
    data = buf.getvalue()
    digest = hashlib.sha256(data).hexdigest()
    if digest != info["sha256"]:
        raise UpdateError("checksum mismatch - the download is corrupted or not the published file")
    return data


def install(files: dict[str, bytes], root: Path, old_version: str = APP_VERSION) -> dict:
    """Write the new files over the app folder (backing up what they replace)."""
    backup = root / "data" / "update" / f"backup-{old_version}"
    changed, req_changed = [], False
    for rel, content in sorted(files.items()):
        dest = root / rel
        if dest.exists() and dest.read_bytes() == content:
            continue
        if dest.exists():
            b = backup / rel
            b.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(dest, b)
        dest.parent.mkdir(parents=True, exist_ok=True)
        tmp = dest.with_name(dest.name + ".new")
        tmp.write_bytes(content)
        tmp.replace(dest)
        changed.append(rel)
        req_changed |= rel == "requirements.txt"
    return {"changed": changed, "requirements_changed": req_changed, "backup": str(backup)}


def pip_install(root: Path) -> None:
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    exe = Path(sys.executable)
    if exe.name.lower() == "pythonw.exe" and (exe.parent / "python.exe").exists():
        exe = exe.parent / "python.exe"
    r = subprocess.run([str(exe), "-m", "pip", "install", "-q", "--disable-pip-version-check", "-r",
                        str(root / "requirements.txt")], capture_output=True, text=True, creationflags=flags)
    if r.returncode != 0:
        raise UpdateError(f"pip install failed: {r.stderr[-300:]}")


def apply(info: dict, root: Path, progress=None) -> dict:
    """Download, verify and install one release. Caller restarts the app afterwards."""
    log("update", f"downloading {info['latest']} from {info['url']}")
    data = download(info, progress)
    files = inspect_zip(data, info["latest"])
    result = install(files, root)
    if result["requirements_changed"]:
        log("update", "requirements changed, running pip")
        pip_install(root)
    log("update", f"installed {info['latest']}: {len(result['changed'])} files changed")
    return result
