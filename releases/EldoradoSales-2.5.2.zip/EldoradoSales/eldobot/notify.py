"""Send messages to the console and (optionally) a Discord webhook."""
from __future__ import annotations

import requests

from .util import log


class Notifier:
    def __init__(self, webhook_url: str = "", mention: str = "", session=None):
        self.webhook_url = (webhook_url or "").strip()
        self.mention = (mention or "").strip()
        self.http = session or requests.Session()

    def send(self, tag: str, text: str, alert: bool = False) -> None:
        log(tag, text.replace("\n", " | "))
        if not self.webhook_url:
            return
        content = text
        if alert and self.mention:
            content = f"{self.mention} {content}"
        try:
            resp = self.http.post(
                self.webhook_url,
                json={"content": content[:1990], "allowed_mentions": {"parse": ["users", "roles", "everyone"]}},
                timeout=15,
            )
            if resp.status_code >= 300:
                log("discord", f"webhook HTTP {resp.status_code}: {resp.text[:150]}")
        except requests.RequestException as exc:
            log("discord", f"webhook error {type(exc).__name__}")
