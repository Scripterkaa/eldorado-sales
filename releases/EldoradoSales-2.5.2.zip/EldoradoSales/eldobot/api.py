"""Thin client for the Eldorado Seller API (spec: /swagger/seller/swagger.json)."""
from __future__ import annotations

import time
from datetime import datetime

import requests

from .util import iso_utc, log

BASE_URL = "https://www.eldorado.gg"  # not eldorado.gg: it 301-redirects
# Deliberately no price endpoints here: this app never edits prices (removed 2026-11-12 on request).


class ApiError(RuntimeError):
    def __init__(self, status: int, method: str, path: str, body: str):
        super().__init__(f"{method} {path} -> HTTP {status}: {body[:300]}")
        self.status = status


class EldoradoApi:
    def __init__(self, auth=None, session: requests.Session | None = None, timeout: float = 30):
        self.auth = auth
        self.http = session or requests.Session()
        self.http.headers.update(
            {"Accept": "application/json", "User-Agent": "eldorado-seller-bot/1.0"}
        )
        self.timeout = timeout

    # ------------------------------------------------------------------ core
    def request(self, method: str, path: str, *, params=None, json=None, private=True, raw=False):
        retried_auth = False
        for attempt in range(4):
            headers = self.auth.headers() if private and self.auth else None
            try:
                resp = self.http.request(
                    method, BASE_URL + path, params=params, json=json,
                    headers=headers, timeout=self.timeout,
                )
            except requests.RequestException as exc:
                if attempt == 3:
                    raise
                log("api", f"{method} {path} network error {type(exc).__name__}, retrying")
                time.sleep(2 * (attempt + 1))
                continue
            if resp.status_code == 401 and private and self.auth and not retried_auth:
                retried_auth = True
                self.auth.refresh()
                continue
            if resp.status_code == 429 or resp.status_code >= 500:
                if attempt == 3:
                    break
                wait = float(resp.headers.get("Retry-After") or 5 * (attempt + 1))
                log("api", f"{method} {path} HTTP {resp.status_code}, waiting {wait:.0f}s")
                time.sleep(min(wait, 60))
                continue
            break
        if resp.status_code >= 400:
            raise ApiError(resp.status_code, method, path, resp.text)
        if raw:
            return resp.text
        if not resp.content:
            return None
        try:
            return resp.json()
        except ValueError:
            return resp.text

    # --------------------------------------------------------------- account
    def seller_api_eligibility(self) -> dict:
        return self.request("GET", "/api/v1/orders/me/seller-api-eligibility")

    def switch_online(self) -> None:
        self.request("PUT", "/api/offerUser/me/switchOnline")

    def switch_offline(self) -> None:
        self.request("PUT", "/api/offerUser/me/switchOffline")

    # ---------------------------------------------------------------- orders
    def seller_orders(self, page_size: int = 50, cursor: str | None = None, group: str | None = None) -> dict:
        """Newest first. Pass the previous page's nextPageCursor to go further back.
        group="Historical" lists old orders (about 3+ months) that the default list leaves out."""
        params = {"displayFilter": "DisplaySellingOrders", "pageSize": page_size}
        if group:
            params["orderGroup"] = group
        if cursor:
            params.update({"cursorValue": cursor, "pageDirection": "Next"})
        return self.request("GET", "/api/v1/orders/me/seller/orders", params=params)

    def deliver_order(self, order_id: str) -> dict:
        return self.request("PUT", f"/api/v1/orders/me/{order_id}/deliver")

    def sold_order_csv(self, start: datetime, end: datetime) -> str:
        """CSV: Order Date,Description,Amount $,Seller Fees $,Net Income $,Category (UTC dates)."""
        params = {"fromDate": iso_utc(start), "untilDate": iso_utc(end)}
        return self.request("GET", "/api/v1/orders/me/sold-order-data", params=params, raw=True)

    # ---------------------------------------------------------------- offers
    # pageSize above 50 is rejected with HTTP 400 "invalid values: PageSize"
    def my_item_offers(self, page: int = 1, page_size: int = 50) -> dict:
        params = {"pageIndex": page, "pageSize": page_size}
        return self.request("GET", "/api/v1/item-management/me/offers", params=params)

    def my_account_offers(self, page: int = 1, page_size: int = 50) -> dict:
        params = {"pageIndex": page, "pageSize": page_size}
        return self.request("GET", "/api/flexibleOffers/me/search", params=params)

    def all_my_offers(self) -> list[tuple[str, dict]]:
        """Every item + account offer as (kind, offer) pairs."""
        out: list[tuple[str, dict]] = []
        for kind, fetch in (("item", self.my_item_offers), ("account", self.my_account_offers)):
            page = 1
            while True:
                data = fetch(page=page) or {}
                out.extend((kind, o) for o in data.get("results") or [])
                if page >= (data.get("totalPages") or 1):
                    break
                page += 1
        return out
