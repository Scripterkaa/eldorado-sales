"""Seller API auth: OAuth2-style client credentials (Dashboard > Seller API).

POST /api/authentication/seller/token {"clientId", "clientSecret"}
  -> {"accessToken", "expiresIn": 900, "tokenType": "Bearer"}
Every private call then sends "Authorization: Bearer <accessToken>". Tokens live 15 minutes.
Note: eldorado.gg (no www) answers 301, which would turn the POST into a GET, so always use www.
"""
from __future__ import annotations

import threading
import time

import requests

from .util import log

TOKEN_URL = "https://www.eldorado.gg/api/authentication/seller/token"
REFRESH_MARGIN = 60  # get a new token 1 minute before the old one expires


class AuthError(RuntimeError):
    pass


class ClientCredentialsAuth:
    def __init__(self, client_id: str, client_secret: str, session: requests.Session | None = None):
        if not client_id or not client_secret:
            raise AuthError(
                "ELDORADO_CLIENT_ID / ELDORADO_CLIENT_SECRET missing - generate them at "
                "eldorado.gg Dashboard > Seller API and put them in .env"
            )
        self.client_id = client_id.strip()
        self.client_secret = client_secret.strip()
        self.http = session or requests.Session()
        self.token: str | None = None
        self.expires_at = 0.0
        self._lock = threading.Lock()  # bot thread + GUI thread share one token

    def headers(self) -> dict:
        with self._lock:
            if not self.token or time.time() > self.expires_at - REFRESH_MARGIN:
                self._refresh()
            return {"Authorization": f"Bearer {self.token}"}

    def refresh(self) -> str:
        with self._lock:
            return self._refresh()

    def _refresh(self) -> str:
        resp = None
        for attempt in range(3):
            try:
                resp = self.http.post(
                    TOKEN_URL,
                    json={"clientId": self.client_id, "clientSecret": self.client_secret},
                    headers={"Accept": "application/json"},
                    timeout=30,
                )
                break
            except requests.RequestException as exc:
                # tokens live 15 min; by then Eldorado has dropped our idle keep-alive connection
                # ("connection forcibly closed"). Start a fresh session and try again.
                if attempt == 2:
                    raise AuthError(f"token request failed: {type(exc).__name__}: {exc}") from exc
                self.http = requests.Session()
                time.sleep(1 + attempt)
        if resp.status_code != 200:
            hint = ""
            if resp.status_code in (400, 401, 403):
                hint = " (client id/secret wrong, revoked or expired - generate a new credential)"
            raise AuthError(f"token request HTTP {resp.status_code}: {resp.text[:200]}{hint}")
        data = resp.json()
        token = data.get("accessToken")
        if not token:
            raise AuthError(f"token response has no accessToken: {str(data)[:200]}")
        self.token = token
        self.expires_at = time.time() + float(data.get("expiresIn") or 900)
        log("auth", f"access token ok, valid {int(self.expires_at - time.time())}s (client {self.client_id[:6]}...)")
        return token
