"""Feature 1: watch seller orders, notify new orders / disputes / reviews, optional auto-deliver."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from .util import JsonStore, log, money, parse_dt

ALERT_STATES = {"Disputed", "DeliveredDisputed"}
INFO_STATES = {"Canceled"}
DONE_STATES = {"Received", "Completed"}
KEEP_DAYS = 14


def order_line(o: dict) -> str:
    det = o.get("orderOfferDetails") or {}
    title = (det.get("offerTitle") or "?").strip()
    total = (o.get("totalPrice") or {}).get("amount") or 0
    qty = o.get("purchaseQuantity") or 1
    state = (o.get("state") or {}).get("state", "?")
    buyer = o.get("buyerUsername") or "?"
    return f"{title} x{qty} = {money(total)} [{state}] buyer {buyer} (order {o.get('id', '')[:8]})"


class OrderWatcher:
    def __init__(self, api, notifier, store: JsonStore, cfg: dict, notes=None):
        self.api = api
        self.notify = notifier
        self.store = store
        self.notes = notes  # BuyerNotes: warn when a buyer tagged watch/bad orders again
        self.page_size = int(cfg.get("page_size", 50))
        self.notify_new = bool(cfg.get("notify_new", True))
        self.notify_done = bool(cfg.get("notify_completed", False))
        self.auto_deliver = {str(x).lower() for x in cfg.get("auto_deliver_offer_ids") or []}

    @property
    def seen(self) -> dict:
        return self.store.data.setdefault("orders", {})

    def poll(self) -> dict:
        data = self.api.seller_orders(page_size=self.page_size) or {}
        orders = data.get("results") or []
        first_run = not self.store.data.get("orders_initialized")
        stats = {"new": 0, "changed": 0}
        cutoff = datetime.now(timezone.utc) - timedelta(days=KEEP_DAYS)

        for o in reversed(orders):  # oldest first so messages arrive in order
            oid = o.get("id")
            if not oid:
                continue
            state = (o.get("state") or {}).get("state")
            review = (o.get("review") or {}).get("reviewRating")
            prev = self.seen.get(oid)

            if prev is None:
                if self._older_than(o.get("createdDate"), cutoff):
                    continue  # already pruned from memory; never re-announce old orders
                self.seen[oid] = {"state": state, "review": review, "created": o.get("createdDate")}
                if first_run:
                    continue
                stats["new"] += 1
                self._on_new(o, state)
                continue

            if state != prev.get("state"):
                stats["changed"] += 1
                self._on_state_change(o, prev.get("state"), state)
                prev["state"] = state
            if review and review != prev.get("review"):
                self._on_review(o, review)
                prev["review"] = review

        if first_run:
            self.store.data["orders_initialized"] = True
            log("orders", f"first run: remembered {len(orders)} existing orders (no alerts sent)")
        self._prune()
        self.store.save()
        return stats

    # ----------------------------------------------------------------- events
    def _flag(self, o: dict) -> tuple[str, bool]:
        """(' | FLAGGED BUYER [...]', True) for buyers tagged watch/bad; VIPs get a short marker."""
        if not self.notes:
            return "", False
        self.notes.reload()
        warn = self.notes.warning(o.get("buyerUsername"))
        if warn:
            note = f" note: {warn['note'][:150]}" if warn.get("note") else ""
            return f" | FLAGGED BUYER [{self.notes.label(warn)}]{note}", True
        e = self.notes.get(o.get("buyerUsername"))
        return (" | VIP", False) if e and "vip" in (e.get("tags") or []) else ("", False)

    def _on_new(self, o: dict, state: str) -> None:
        offer_id = str(o.get("offerId", "")).lower()
        flag, warn = self._flag(o)
        if state == "Paid" and offer_id in self.auto_deliver and not warn:
            try:
                self.api.deliver_order(o["id"])
                self.seen[o["id"]]["state"] = "Delivered"
                self.notify.send("orders", f"AUTO-DELIVERED: {order_line(o)}{flag}")
                return
            except Exception as exc:
                self.notify.send("orders", f"AUTO-DELIVER FAILED ({exc}): {order_line(o)}{flag}", alert=True)
                return
        if state == "Paid":
            self.notify.send("orders", f"NEW ORDER - NEEDS DELIVERY: {order_line(o)}{flag}", alert=True)
        elif state in ALERT_STATES:
            self.notify.send("orders", f"NEW ORDER ALREADY DISPUTED: {order_line(o)}{flag}", alert=True)
        elif warn:
            self.notify.send("orders", f"FLAGGED BUYER ORDERED: {order_line(o)}{flag}", alert=True)
        elif self.notify_new:
            self.notify.send("orders", f"New order: {order_line(o)}{flag}")

    def _on_state_change(self, o: dict, old: str, new: str) -> None:
        if new in ALERT_STATES:
            reason = ((o.get("latestDispute") or {}).get("reason") or "").replace("_", " ")
            msg = (o.get("latestDispute") or {}).get("message") or ""
            self.notify.send("orders", f"DISPUTE ({reason}): {order_line(o)} :: {msg[:300]}", alert=True)
        elif new in INFO_STATES:
            reason = ((o.get("cancelation") or {}).get("reason") or "").replace("_", " ")
            self.notify.send("orders", f"Order canceled ({reason}): {order_line(o)}")
        elif new in DONE_STATES and self.notify_done:
            self.notify.send("orders", f"Order {new.lower()}: {order_line(o)}")
        else:
            log("orders", f"{o.get('id', '')[:8]} {old} -> {new}")

    def _on_review(self, o: dict, rating: str) -> None:
        msg = ((o.get("review") or {}).get("reviewMessage") or "").strip()
        if rating == "Negative":
            self.notify.send("orders", f"NEGATIVE REVIEW: {order_line(o)} :: {msg[:300]}", alert=True)
        else:
            self.notify.send("orders", f"Positive review: {order_line(o)} {(':: ' + msg[:200]) if msg else ''}")

    @staticmethod
    def _older_than(created: str | None, cutoff: datetime) -> bool:
        try:
            return bool(created) and parse_dt(created) < cutoff
        except ValueError:
            return False

    def _prune(self) -> None:
        cutoff = datetime.now(timezone.utc) - timedelta(days=KEEP_DAYS)
        for oid in list(self.seen):
            if self._older_than(self.seen[oid].get("created"), cutoff):
                del self.seen[oid]
