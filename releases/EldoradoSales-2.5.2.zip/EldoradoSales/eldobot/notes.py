"""Private notes and tags on buyers (kept only on this computer, in data/buyer_notes.json)."""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from .util import JsonStore

TAGS = {"vip": "VIP", "watch": "ระวัง", "bad": "มีปัญหา"}
WARN_TAGS = {"watch", "bad"}


def key(name: str | None) -> str:
    return (name or "").strip().lower()


class BuyerNotes:
    def __init__(self, path: Path):
        self.store = JsonStore(path)
        self.store.data.setdefault("buyers", {})

    @property
    def all(self) -> dict:
        return self.store.data["buyers"]

    def reload(self) -> None:
        """Pick up edits made by another part of the app (the file is the source of truth)."""
        fresh = JsonStore(self.store.path)
        self.store.data = fresh.data or {"buyers": {}}
        self.store.data.setdefault("buyers", {})

    def get(self, name: str | None) -> dict | None:
        return self.all.get(key(name))

    def set(self, name: str, tags: list[str], note: str) -> dict | None:
        k = key(name)
        if not k:
            raise ValueError("ไม่มีชื่อผู้ซื้อ")
        tags = [t for t in dict.fromkeys(tags or []) if t in TAGS]
        note = (note or "").strip()[:2000]
        if not tags and not note:
            self.all.pop(k, None)
            self.store.save()
            return None
        entry = {"name": name.strip(), "tags": tags, "note": note,
                 "updated": datetime.now(timezone.utc).isoformat(timespec="seconds")}
        self.all[k] = entry
        self.store.save()
        return entry

    def warning(self, name: str | None) -> dict | None:
        """The entry if this buyer is tagged 'watch' or 'bad'."""
        e = self.get(name)
        return e if e and WARN_TAGS.intersection(e.get("tags") or []) else None

    @staticmethod
    def label(entry: dict) -> str:
        return " / ".join(TAGS[t] for t in entry.get("tags") or [] if t in TAGS)
