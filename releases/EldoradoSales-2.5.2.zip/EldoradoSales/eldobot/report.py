"""Feature 4: daily sales summary, counted by DELIVERY day.

User rule (2026-11-11): a day's sales = orders delivered that day - not orders received/completed
that day. The sold-order CSV (whose "Order Date" is the Completed time) is only used to learn the
real fee rate, so the report can show an estimated net.
"""
from __future__ import annotations

import csv
import io
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date, datetime, time as dtime, timedelta, timezone

from .history import day_stats, slim
from .util import log, money, parse_dt

MAX_ORDER_PAGES = 60
DELIVERY_LAG_DAYS = 3   # an order delivered on day D may have been created a few days earlier
FEE_SAMPLE_DAYS = 7


@dataclass
class Totals:
    orders: int = 0
    gross: float = 0.0
    fees: float = 0.0
    net: float = 0.0
    by_category: dict = field(default_factory=lambda: defaultdict(lambda: [0, 0.0, 0.0]))


def _num(value: str) -> float:
    try:
        return float(str(value).replace(",", "").replace("$", "").strip() or 0)
    except ValueError:
        return 0.0


def parse_sold_csv(text: str) -> Totals:
    t = Totals()
    reader = csv.DictReader(io.StringIO((text or "").lstrip("﻿")))
    for row in reader:
        row = {(k or "").strip(): v for k, v in row.items()}
        if not row.get("Order Date"):
            continue
        gross, fees, net = _num(row.get("Amount $")), _num(row.get("Seller Fees $")), _num(row.get("Net Income $"))
        t.orders += 1
        t.gross += gross
        t.fees += fees
        t.net += net
        cat = t.by_category[(row.get("Category") or "Other").strip()]
        cat[0] += 1
        cat[1] += gross
        cat[2] += net
    return t


def day_bounds(day: date, tz) -> tuple[datetime, datetime]:
    start = datetime.combine(day, dtime(0, 0), tzinfo=tz)
    return start.astimezone(timezone.utc), (start + timedelta(days=1)).astimezone(timezone.utc)


def orders_in_range(api, start: datetime, end: datetime) -> list[dict]:
    """Walk the newest-first order list back until we pass `start` (by created date)."""
    out, cursor = [], None
    for _ in range(MAX_ORDER_PAGES):
        data = api.seller_orders(page_size=50, cursor=cursor) or {}
        results = data.get("results") or []
        for o in results:
            created = parse_dt(o["createdDate"])
            if start <= created < end:
                out.append(o)
        if not results or parse_dt(results[-1]["createdDate"]) < start:
            break
        cursor = data.get("nextPageCursor")
        if not cursor:
            break
    return out


def fee_rate(api, start: datetime, end: datetime) -> float | None:
    """Eldorado's real fee share (fees / gross) from the sold-order CSV, or None if unavailable."""
    try:
        t = parse_sold_csv(api.sold_order_csv(start, end))
    except Exception as exc:  # the API may not allow sales reports
        log("report", f"sales CSV unavailable ({exc}); no net estimate")
        return None
    return t.fees / t.gross if t.gross > 0 else None


def _delta(now: float, before: float) -> str:
    d = now - before
    return f"{'+' if d >= 0 else '-'}{money(abs(d))} vs prev day {money(before)}"


def format_day(st, prev, rate: float | None, tz, top_n: int = 8) -> str:
    lines = [f"Daily sales {st.day.isoformat()} ({tz}) - counted by delivery"]
    net = f" | Net ~{money(st.gross * (1 - rate))} (fee {rate:.1%})" if rate is not None else ""
    lines.append(f"Delivered {st.orders} orders | Gross {money(st.gross)}{net} ({_delta(st.gross, prev.gross)})")
    if st.per_offer:
        lines.append("Top offers:")
        for title, (n, total) in sorted(st.per_offer.items(), key=lambda kv: -kv[1][1])[:top_n]:
            lines.append(f"  {n}x {title[:70]} = {money(total)}")
    problems = []
    if st.disputed:
        problems.append(f"Disputed {st.disputed}")
    if st.canceled:
        problems.append(f"Canceled {st.canceled} (not counted)")
    if problems:
        lines.append("Problems: " + ", ".join(problems))
    return "\n".join(lines)


def build_report(api, day: date, tz, top_n: int = 8) -> str:
    start, end = day_bounds(day, tz)
    prev_day = day - timedelta(days=1)
    prev_start, _ = day_bounds(prev_day, tz)
    orders = orders_in_range(api, prev_start - timedelta(days=DELIVERY_LAG_DAYS), end)
    stats = day_stats([slim(o) for o in orders], prev_day, day, tz)
    rate = fee_rate(api, start - timedelta(days=FEE_SAMPLE_DAYS), end)
    return format_day(stats[day], stats[prev_day], rate, tz, top_n)
