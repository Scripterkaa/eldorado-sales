"""Local web server behind the sales dashboard window (127.0.0.1 only, token-protected).

The page in ui/ calls these JSON endpoints:
  GET  /api/dashboard?days=N     KPIs, daily series, offers, hours, weekdays, recent orders
  GET  /api/day?date=YYYY-MM-DD  one day's detail
  POST /api/sync {"days": N}     refresh the order cache in the background; GET /api/sync = progress
  GET/POST /api/settings         credentials (secrets never sent back), Discord, bot features
  GET/POST /api/bot              background bot (order alerts, daily report, shop schedule)
  POST /api/send-day {"date"}    post one day's summary to Discord
  POST /api/heartbeat            the window is still open
Nothing here edits offer prices.
"""
from __future__ import annotations

import json
import re
import threading
import time
import webbrowser
from datetime import date, datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse
from zoneinfo import ZoneInfo

from .api import EldoradoApi
from .auth import AuthError, ClientCredentialsAuth
from .buyers import profile as buyer_profile, search as buyer_search
from .chats import ChatState, unread_chats
from .config import ROOT, load_config, save_config, save_env
from .history import OrderHistory, day_stats
from .notes import BuyerNotes
from .notify import Notifier
from .report import fee_rate, format_day
from .stock import RATE_DAYS, is_low, offer_rows
from . import updater
from .runner import Runner
from .sales import dashboard, day_detail, sync_days_needed
from .util import JsonStore, log
from .version import APP_VERSION

UI_DIR = ROOT / "ui"
STATIC = {"/": ("index.html", "text/html; charset=utf-8"),
          "/app.js": ("app.js", "text/javascript; charset=utf-8"),
          "/style.css": ("style.css", "text/css; charset=utf-8"),
          "/icon.png": ("icon.png", "image/png")}
UPDATE_CHECK_TTL = 6 * 3600
STOCK_TTL = 90
ORDER_ID = re.compile(r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")
FEE_TTL = 3600
DEEP_REFRESH_EVERY = 1800


class SalesService:
    def __init__(self):
        self.cfg = load_config()
        self.store = JsonStore(ROOT / "data" / "state.json")
        self.lock = threading.Lock()
        self.sync_lock = threading.Lock()
        self.sync_state = {"running": False, "pages": 0, "oldest": None, "error": None, "finished": None}
        self.runner: Runner | None = None
        self.runner_thread: threading.Thread | None = None
        self.last_heartbeat = 0.0
        self.last_deep_refresh = 0.0
        self._fee = (None, 0.0)
        self.update_info: dict | None = None
        self.update_checked = 0.0
        self.update_state = {"running": False, "step": "", "error": None, "done": False}
        self.restart_requested = threading.Event()
        self.notes = BuyerNotes(ROOT / "data" / "buyer_notes.json")
        self.chat_state = ChatState(ROOT / "data" / "chat_read.json")
        self._stock = (None, 0.0)
        self._build_clients()

    # ------------------------------------------------------------ clients
    def _build_clients(self) -> None:
        self.notifier = Notifier(self.cfg["discord_webhook"], self.cfg["discord_mention"])
        try:
            self.auth = ClientCredentialsAuth(self.cfg["_client_id"], self.cfg["_client_secret"])
            self.api = EldoradoApi(self.auth)
            self.history = OrderHistory(EldoradoApi(self.auth), ROOT / "data" / "orders_cache.json")
        except AuthError:
            self.auth = self.api = self.history = None

    @property
    def tz(self):
        return self.cfg["_tz"]

    # --------------------------------------------------------------- sync
    def start_sync(self, range_days: int) -> dict:
        if not self.history:
            return {**self.sync_state, "error": "ยังไม่ได้ใส่ Client ID / Secret"}
        with self.lock:
            if self.sync_state["running"]:
                return dict(self.sync_state)
            self.sync_state.update(running=True, pages=0, oldest=None, error=None)
        days = sync_days_needed(range_days, datetime.now(timezone.utc), self.tz)
        threading.Thread(target=self._sync_worker, args=(days,), daemon=True).start()
        return dict(self.sync_state)

    def _sync_worker(self, days: int) -> None:
        def progress(pages, oldest):
            self.sync_state.update(pages=pages, oldest=oldest.astimezone(self.tz).isoformat() if oldest else None)
        # every 30 min re-read 14 days: disputes/cancellations can land days after delivery
        deep = time.time() - self.last_deep_refresh > DEEP_REFRESH_EVERY
        try:
            with self.sync_lock:
                self.history.sync(days, progress=progress, refresh_days=14 if deep else 3)
                self.history.backfill_historical()  # once: Jun-Jul orders for buyer history
            if deep:
                self.last_deep_refresh = time.time()
            self.sync_state.update(error=None)
        except Exception as exc:  # noqa: BLE001
            log("error", f"sync failed: {type(exc).__name__}: {exc}")
            self.sync_state.update(error=f"{type(exc).__name__}: {exc}")
        finally:
            self.sync_state.update(running=False, finished=datetime.now(self.tz).isoformat())

    def _rate(self) -> float | None:
        rate, at = self._fee
        if self.api and time.time() - at > FEE_TTL:
            now = datetime.now(timezone.utc)
            rate = fee_rate(self.api, now - timedelta(days=30), now)
            self._fee = (rate, time.time())
        return rate

    # --------------------------------------------------------- dashboards
    def dashboard(self, days: int) -> dict:
        if not self.history:
            return {"needs_setup": True}
        with self.sync_lock:
            orders = dict(self.history.orders)
            covered = self.history.covered_from()
        self.notes.reload()
        now = datetime.now(timezone.utc)
        data = dashboard(orders, now, self.tz, days, self._rate(), covered, notes=self.notes.all)
        self.chat_state.reload()
        data["chats"] = unread_chats(orders, self.chat_state, self.tz, now)
        data.update(seller=self.history.store.data.get("seller"), synced_at=self.history.store.data.get("synced_at"),
                    cached=len(orders), sync=dict(self.sync_state), bot=self.bot_status())
        return data

    def day(self, day: date) -> dict:
        with self.sync_lock:
            orders = dict(self.history.orders)
        return day_detail(orders, day, self.tz, self._rate())

    def buyers(self, q: str) -> dict:
        with self.sync_lock:
            orders = dict(self.history.orders)
        return buyer_search(orders, q, self.tz)

    def buyer(self, name: str) -> dict:
        with self.sync_lock:
            orders = dict(self.history.orders)
        p = buyer_profile(orders, name, self.tz)
        if p is None:
            raise ValueError(f"ไม่พบผู้ซื้อชื่อ {name}")
        return p

    # --------------------------------------------------------- stock / notes
    def stock(self, force: bool = False) -> dict:
        rows, at = self._stock
        if not self.api:
            return {"rows": [], "error": "ยังไม่ได้ใส่ Client ID / Secret"}
        if force or rows is None or time.time() - at > STOCK_TTL:
            offers = self.api.all_my_offers()
            with self.sync_lock:
                orders = list(self.history.orders.values())
            rows = offer_rows(offers, orders, self.tz)
            self._stock = (rows, time.time())
        s = self.cfg["stock"]
        for r in rows:
            r["low"] = is_low(r, int(s["min_qty"]), float(s["min_days"]))
        return {"rows": rows, "min_qty": s["min_qty"], "min_days": s["min_days"], "alerts": s["enabled"],
                "rate_days": RATE_DAYS, "checked": datetime.fromtimestamp(at or time.time(), self.tz).isoformat()}

    def mark_chats_read(self, p: dict) -> dict:
        with self.sync_lock:
            orders = dict(self.history.orders) if self.history else {}
        self.chat_state.reload()
        if p.get("all"):
            ids = [r["id"] for r in unread_chats(orders, self.chat_state, self.tz)]
        else:
            ids = [str(i) for i in p.get("ids") or []]
        n = self.chat_state.mark(orders, ids)
        return {"ok": True, "marked": n, "chats": unread_chats(orders, self.chat_state, self.tz)}

    def save_note(self, p: dict) -> dict:
        entry = self.notes.set(str(p.get("name", "")), list(p.get("tags") or []), str(p.get("note", "")))
        return {"ok": True, "entry": entry, "all": self.notes.all}

    # ------------------------------------------------------------- updates
    def check_update(self, force: bool = False) -> dict:
        if updater.is_dev_copy(ROOT):  # never overwrite the developer's working folder
            return {"current": APP_VERSION, "available": False, "dev": True, "state": dict(self.update_state)}
        if force or not self.update_info or time.time() - self.update_checked > UPDATE_CHECK_TTL:
            try:
                self.update_info = updater.check()
            except Exception as exc:  # offline / no release yet: not an error for the user
                self.update_info = {"current": APP_VERSION, "available": False, "error": str(exc)}
            self.update_checked = time.time()
        return {**self.update_info, "current": APP_VERSION, "state": dict(self.update_state)}

    def start_update(self) -> dict:
        info = self.check_update(force=True)
        if not info.get("available"):
            raise ValueError("ไม่มีอัปเดตใหม่")
        if self.update_state["running"]:
            return dict(self.update_state)
        self.update_state.update(running=True, step="กำลังดาวน์โหลด…", error=None, done=False)

        def work():
            def progress(got, total):
                pct = f" {got * 100 // total}%" if total else ""
                self.update_state["step"] = f"กำลังดาวน์โหลด…{pct}"
            try:
                updater.apply(info, ROOT, progress)
                self.update_state.update(step="ติดตั้งเสร็จ กำลังเปิดใหม่…", done=True)
                time.sleep(0.8)  # let the page read the final state
                self.restart_requested.set()
            except Exception as exc:  # noqa: BLE001
                log("error", f"update failed: {exc}")
                self.update_state.update(error=str(exc), step="")
            finally:
                self.update_state["running"] = False
        threading.Thread(target=work, daemon=True).start()
        return dict(self.update_state)

    @staticmethod
    def open_order(order_id: str) -> dict:
        """Open the order on eldorado.gg in the user's normal browser (where they are logged in)."""
        if not ORDER_ID.fullmatch(order_id or ""):
            raise ValueError("เลขออเดอร์ไม่ถูกต้อง")
        webbrowser.open(f"https://www.eldorado.gg/order/{order_id}")
        return {"ok": True}

    def send_day(self, day: date) -> dict:
        if not self.cfg["discord_webhook"]:
            raise ValueError("ยังไม่ได้ใส่ Discord webhook (ตั้งค่า)")
        with self.sync_lock:
            orders = list(self.history.orders.values())
        stats = day_stats(orders, day - timedelta(days=1), day, self.tz)
        text = format_day(stats[day], stats[day - timedelta(days=1)], self._rate(), self.tz,
                          int(self.cfg["report"].get("top_offers", 8)))
        self.notifier.send("report", text)
        return {"ok": True}

    # ----------------------------------------------------------- settings
    def settings(self) -> dict:
        c = self.cfg
        return {
            "client_id": c["_client_id"], "has_secret": bool(c["_client_secret"]),
            "has_webhook": bool(c["discord_webhook"]), "mention": c["discord_mention"],
            "timezone": c["timezone"],
            "orders_enabled": c["orders"]["enabled"], "orders_interval": c["orders"]["interval_seconds"],
            "notify_new": c["orders"].get("notify_new", True),
            "report_enabled": c["report"]["enabled"], "report_time": c["report"]["time"],
            "schedule_enabled": c["schedule"]["enabled"],
            "schedule_windows": ", ".join(f"{a}-{b}" for a, b in c["schedule"].get("online") or []),
            "stock_enabled": c["stock"]["enabled"], "stock_min_qty": c["stock"]["min_qty"],
            "stock_min_days": c["stock"]["min_days"], "chats_enabled": c["chats"]["enabled"],
        }

    def save_settings(self, p: dict) -> dict:
        c = self.cfg
        windows = []
        for part in [x.strip() for x in str(p.get("schedule_windows", "")).split(",") if x.strip()]:
            m = re.fullmatch(r"(\d{1,2}:\d{2})\s*-\s*(\d{1,2}:\d{2})", part)
            if not m:
                raise ValueError(f"ช่วงเวลาไม่ถูกต้อง: {part}")
            windows.append([m.group(1).zfill(5), m.group(2).zfill(5)])
        if not re.fullmatch(r"\d{1,2}:\d{2}", str(p.get("report_time", c["report"]["time"]))):
            raise ValueError("เวลาส่งรายงานต้องเป็น HH:MM")
        interval = int(p.get("orders_interval", c["orders"]["interval_seconds"]))
        if interval < 20:
            raise ValueError("เช็กออเดอร์ถี่สุดได้ทุก 20 วินาที")
        tzname = str(p.get("timezone") or c["timezone"])
        tz = ZoneInfo(tzname)

        env = {"ELDORADO_CLIENT_ID": str(p.get("client_id", c["_client_id"])).strip()}
        if p.get("client_secret"):
            env["ELDORADO_CLIENT_SECRET"] = str(p["client_secret"]).strip()
        if p.get("webhook") is not None and p.get("webhook") != "":
            env["DISCORD_WEBHOOK"] = str(p["webhook"]).strip()
        if p.get("clear_webhook"):
            env["DISCORD_WEBHOOK"] = ""
        save_env(env)
        c["_client_id"] = env["ELDORADO_CLIENT_ID"]
        c["_client_secret"] = env.get("ELDORADO_CLIENT_SECRET", c["_client_secret"])
        if "DISCORD_WEBHOOK" in env:
            c["discord_webhook"] = env["DISCORD_WEBHOOK"]
        c["discord_mention"] = str(p.get("mention", c["discord_mention"])).strip()
        c["timezone"], c["_tz"] = tzname, tz
        c["orders"]["enabled"] = bool(p.get("orders_enabled", c["orders"]["enabled"]))
        c["orders"]["interval_seconds"] = interval
        c["orders"]["notify_new"] = bool(p.get("notify_new", c["orders"].get("notify_new", True)))
        c["report"]["enabled"] = bool(p.get("report_enabled", c["report"]["enabled"]))
        c["report"]["time"] = str(p.get("report_time", c["report"]["time"])).zfill(5)
        c["schedule"]["enabled"] = bool(p.get("schedule_enabled", c["schedule"]["enabled"]))
        if windows:
            c["schedule"]["online"] = windows
        c["stock"]["enabled"] = bool(p.get("stock_enabled", c["stock"]["enabled"]))
        c["stock"]["min_qty"] = max(0, int(p.get("stock_min_qty", c["stock"]["min_qty"])))
        c["stock"]["min_days"] = max(0.0, float(p.get("stock_min_days", c["stock"]["min_days"])))
        c["chats"]["enabled"] = bool(p.get("chats_enabled", c["chats"]["enabled"]))
        save_config(c)
        was_running = self.bot_status()["running"]
        if was_running:
            self.bot_stop(wait=True)
        self._build_clients()
        self._fee = (None, 0.0)
        if was_running:
            self.bot_start()
        return self.settings()

    def test_connection(self) -> dict:
        if not self.api:
            raise ValueError("ยังไม่ได้ใส่ Client ID / Secret")
        return {"ok": True, "eligibility": self.api.seller_api_eligibility()}

    def test_discord(self) -> dict:
        if not self.cfg["discord_webhook"]:
            raise ValueError("ยังไม่ได้ใส่ Discord webhook")
        self.notifier.send("test", "Test message from Eldorado Sales", alert=True)
        return {"ok": True}

    # ---------------------------------------------------------------- bot
    def bot_status(self) -> dict:
        running = bool(self.runner_thread and self.runner_thread.is_alive())
        tasks = []
        if running and self.runner:
            for name, interval, _ in self.runner.tasks:
                st = self.runner.status.get(name) or {}
                tasks.append({"name": name, "every": interval, "ok": st.get("ok"),
                              "last": st["last"].strftime("%H:%M:%S") if st.get("last") else None,
                              "msg": st.get("msg", "")})
        return {"running": running, "tasks": tasks}

    def bot_start(self) -> dict:
        if not self.api:
            raise ValueError("ยังไม่ได้ใส่ Client ID / Secret")
        if not self.bot_status()["running"]:
            self.runner = Runner(EldoradoApi(self.auth), self.notifier, self.cfg, self.store,
                                 history=self.history, notes=self.notes)
            if not self.runner.tasks:
                raise ValueError("ยังไม่ได้เปิดงานไหนให้บอทเลย (ตั้งค่า)")
            self.runner_thread = threading.Thread(target=self.runner.run_forever, daemon=True)
            self.runner_thread.start()
        return self.bot_status()

    def bot_stop(self, wait: bool = False) -> dict:
        if self.runner:
            self.runner.stop()
            if wait and self.runner_thread:
                self.runner_thread.join(timeout=30)
        return self.bot_status()


def make_handler(service: SalesService, token: str):
    class Handler(BaseHTTPRequestHandler):
        server_version = "EldoradoSales/2"

        def log_message(self, *_args):  # keep stdout quiet
            pass

        def _send(self, code: int, body: bytes, ctype: str) -> None:
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _json(self, code: int, data) -> None:
            self._send(code, json.dumps(data, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")

        def _authorized(self) -> bool:
            if self.headers.get("X-Token") == token:
                return True
            self._json(403, {"error": "forbidden"})
            return False

        def _body(self) -> dict:
            n = int(self.headers.get("Content-Length") or 0)
            return json.loads(self.rfile.read(n) or b"{}") if n else {}

        def do_GET(self):  # noqa: N802
            url = urlparse(self.path)
            if url.path in STATIC:
                name, ctype = STATIC[url.path]
                return self._send(200, (UI_DIR / name).read_bytes(), ctype)
            if not url.path.startswith("/api/"):
                return self._send(404, b"not found", "text/plain")
            if not self._authorized():
                return None
            q = {k: v[0] for k, v in parse_qs(url.query).items()}
            try:
                if url.path == "/api/dashboard":
                    return self._json(200, service.dashboard(max(7, min(120, int(q.get("days", 30))))))
                if url.path == "/api/day":
                    return self._json(200, service.day(date.fromisoformat(q["date"])))
                if url.path == "/api/sync":
                    return self._json(200, dict(service.sync_state))
                if url.path == "/api/buyers":
                    return self._json(200, service.buyers(q.get("q", "")))
                if url.path == "/api/buyer":
                    try:
                        return self._json(200, service.buyer(q.get("name", "")))
                    except ValueError as exc:
                        return self._json(404, {"error": str(exc)})
                if url.path == "/api/settings":
                    return self._json(200, service.settings())
                if url.path == "/api/bot":
                    return self._json(200, service.bot_status())
                if url.path == "/api/update":
                    return self._json(200, service.check_update(force=q.get("force") == "1"))
                if url.path == "/api/stock":
                    return self._json(200, service.stock(force=q.get("force") == "1"))
                if url.path == "/api/notes":
                    service.notes.reload()
                    return self._json(200, service.notes.all)
                if url.path == "/api/version":
                    return self._json(200, {"version": APP_VERSION, "update": dict(service.update_state)})
                return self._json(404, {"error": "unknown endpoint"})
            except Exception as exc:  # noqa: BLE001
                return self._json(500, {"error": str(exc)})

        def do_POST(self):  # noqa: N802
            url = urlparse(self.path)
            if not self._authorized():
                return None
            try:
                body = self._body()
                if url.path == "/api/heartbeat":
                    service.last_heartbeat = time.time()
                    return self._json(200, {"ok": True})
                if url.path == "/api/sync":
                    return self._json(200, service.start_sync(int(body.get("days", 30))))
                if url.path == "/api/settings":
                    return self._json(200, service.save_settings(body))
                if url.path == "/api/test-connection":
                    return self._json(200, service.test_connection())
                if url.path == "/api/test-discord":
                    return self._json(200, service.test_discord())
                if url.path == "/api/bot":
                    action = body.get("action")
                    return self._json(200, service.bot_start() if action == "start" else service.bot_stop())
                if url.path == "/api/update":
                    return self._json(200, service.start_update())
                if url.path == "/api/notes":
                    return self._json(200, service.save_note(body))
                if url.path == "/api/chats/read":
                    return self._json(200, service.mark_chats_read(body))
                if url.path == "/api/open-order":
                    return self._json(200, service.open_order(str(body.get("id", ""))))
                if url.path == "/api/send-day":
                    return self._json(200, service.send_day(date.fromisoformat(body["date"])))
                return self._json(404, {"error": "unknown endpoint"})
            except (ValueError, KeyError) as exc:
                return self._json(400, {"error": str(exc)})
            except Exception as exc:  # noqa: BLE001
                return self._json(500, {"error": f"{type(exc).__name__}: {exc}"})

    return Handler


def serve(service: SalesService, token: str, port: int) -> ThreadingHTTPServer:
    for attempt in range(40):  # after an in-app update the old process may still hold the port briefly
        try:
            httpd = ThreadingHTTPServer(("127.0.0.1", port), make_handler(service, token))
            break
        except OSError:
            if attempt == 39:
                raise
            time.sleep(0.25)
    httpd.daemon_threads = True
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    return httpd
