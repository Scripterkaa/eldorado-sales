"""Eldorado seller bot - order alerts, shop schedule, daily sales report.

Usage:
  python eldorado_bot.py login              check client id/secret + API eligibility
  python eldorado_bot.py offers             list your offers
  python eldorado_bot.py orders             poll orders once
  python eldorado_bot.py report [--date YYYY-MM-DD] [--no-send]
  python eldorado_bot.py online | offline   switch shop status now
  python eldorado_bot.py run                run everything enabled in config.json (loop)
  pythonw eldorado_gui.py                   sales dashboard app

This tool never changes offer prices.
"""
from __future__ import annotations

import argparse
import sys
from datetime import date, datetime, timedelta

from eldobot.api import ApiError, EldoradoApi
from eldobot.auth import AuthError, ClientCredentialsAuth
from eldobot.config import ROOT, load_config
from eldobot.notify import Notifier
from eldobot.orders import OrderWatcher
from eldobot.report import build_report
from eldobot.runner import Runner
from eldobot.schedule import manual_switch
from eldobot.util import JsonStore, ascii_safe, fail, log, money


def build(cfg):
    try:
        auth = ClientCredentialsAuth(cfg["_client_id"], cfg["_client_secret"])
    except AuthError as exc:
        fail(str(exc))
    api = EldoradoApi(auth)
    notifier = Notifier(cfg["discord_webhook"], cfg["discord_mention"])
    store = JsonStore(ROOT / "data" / "state.json")
    return auth, api, notifier, store


def cmd_login(cfg, auth, api, **_):
    auth.refresh()
    log("login", f"ok, access token valid until {datetime.fromtimestamp(auth.expires_at):%H:%M:%S}")
    log("login", f"seller api eligibility: {api.seller_api_eligibility()}")


def cmd_offers(cfg, api, **_):
    offers = api.all_my_offers()
    for kind, o in offers:
        price = (o.get("pricePerUnitInUSD") or o.get("pricePerUnit") or {}).get("amount", 0)
        title = (o.get("offerTitle") or "").strip()
        log("offers", f"{kind:<7} {o.get('offerState', '?'):<7} {money(price):>9}  stock {o.get('quantity')}  "
                      f"game {o.get('gameId')}  id {o.get('id')}  {ascii_safe(title)[:50]}")
    log("offers", f"{len(offers)} offers")


def cmd_orders(cfg, api, notifier, store, **_):
    stats = OrderWatcher(api, notifier, store, cfg["orders"]).poll()
    log("orders", f"done: {stats}")


def cmd_report(cfg, api, notifier, args, **_):
    tz = cfg["_tz"]
    day = date.fromisoformat(args.date) if args.date else (datetime.now(tz) - timedelta(days=1)).date()
    text = build_report(api, day, tz, int(cfg["report"].get("top_offers", 8)))
    if args.no_send:
        for line in text.splitlines():
            log("report", line)
    else:
        notifier.send("report", text)


def cmd_switch(status):
    def run(cfg, api, notifier, store, **_):
        manual_switch(api, notifier, store, status)
    return run


def cmd_run(cfg, api, notifier, store, **_):
    Runner(api, notifier, cfg, store).run_forever()


def main(argv=None):
    p = argparse.ArgumentParser(description="Eldorado seller bot")
    sub = p.add_subparsers(dest="cmd", required=True)
    for name in ("login", "offers", "orders", "online", "offline", "run"):
        sub.add_parser(name)
    sr = sub.add_parser("report")
    sr.add_argument("--date", help="local date YYYY-MM-DD (default: yesterday)")
    sr.add_argument("--no-send", action="store_true", help="print only, do not post to Discord")
    args = p.parse_args(argv)

    cfg = load_config()
    auth, api, notifier, store = build(cfg)
    handlers = {
        "login": cmd_login, "offers": cmd_offers,
        "orders": cmd_orders, "report": cmd_report, "online": cmd_switch("online"),
        "offline": cmd_switch("offline"), "run": cmd_run,
    }
    try:
        handlers[args.cmd](cfg=cfg, auth=auth, api=api, notifier=notifier, store=store, args=args)
    except (AuthError, ApiError) as exc:
        fail(str(exc))
    except KeyboardInterrupt:
        log("main", "stopped")


if __name__ == "__main__":
    sys.exit(main())
